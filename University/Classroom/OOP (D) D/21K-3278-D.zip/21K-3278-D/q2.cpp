#include <iostream>
#include <string.h>

using namespace std;

int main()
{

    string movie_name;
    float adultPrice;

    cout << "Enter movie name :" << endl;
    cin >> movie_name;

    cout << "Enter adult ticket price :" << endl;
    cin >> adultPrice;







}    