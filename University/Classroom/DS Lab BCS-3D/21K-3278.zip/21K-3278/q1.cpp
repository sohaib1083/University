#include <iostream>
using namespace std;

class node {
    public:
    int data;
    node * next;

    node () { data =0; next = NULL;}
    node (int d) { data =d; next = NULL;}
    

};

class linkedList{
    public:
    node * head;
    linkedList() {head = NULL;}

    void append (int d)
    {
        node * newnode = new node(d);

        if (head == NULL)
        {
            head = newnode;
        }
        else{
            node * temp = head;

            while ( temp->next != NULL)
            {
                temp = temp->next;
            }

            temp->next = newnode; 

        }
    }
    void print ()
    {
        node * temp = head;
         while ( temp != NULL)
        {
             cout<< temp->data<< " ";
             temp = temp->next;
        }
    }

    int removeLoop()
    {
        node * temp = head;
        node * bprev;
        node * prev; 
        node * current;
        while ( temp != NULL)
        {
            bprev= temp;
            temp = temp->next;
            prev = temp;
            temp = temp->next;
            current = temp;

            if (((current->data)-(prev->data)) == 1)
            {
                // delete prev
                bprev->next = prev->next;
                prev->next = NULL;
                delete prev;
                return 1;
            }

        }
    }
};

int main (void)
{
    int N, x;
    int temp;
    cin>>N;
    // int * arr = new int [N];
    linkedList l1;
    cout<< "enter values:"<< endl;
    for (int i=0;i<N; i++)
    {
        cin>> temp;
        l1.append(temp);
    }
    
    cout<< "enter x:"<< endl;
    cin>> x;

    l1.print();

    int ans=l1.removeLoop();
    
    cout<< endl<<"result = "<< ans;
    cout<< endl;
    l1.print();
    return 0;
}