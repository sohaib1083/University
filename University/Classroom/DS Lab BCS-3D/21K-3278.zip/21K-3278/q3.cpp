#include <iostream>
using namespace std;

int Binary_Search(int arr[], int size, int key)
{
    int start = 0, end = size-1, mid, count=0;;
    while(start <= end)
    {
        mid = (start+end)/2;
        count++;
        if(arr[mid] == key)
        {
            cout << "The number of street lights are: " << count << ".\n";
            return mid;
        }
        else if(arr[mid] > key)
        {
            end = mid-1;
        }
        else
        {
            start = mid+1;
        }
    }
    return -1;
}


int main()
{
    int n, k;
    cin>>n>>k;
    int * x = new int [n];

    for (int i=0;i<n; i++)
    {
        cin>>x[i];
    }

    Binary_Search(x, n, k);
    return 0;
}