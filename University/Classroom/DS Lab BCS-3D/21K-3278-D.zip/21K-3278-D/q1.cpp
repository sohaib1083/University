#include <iostream>
using namespace std;

int findMax_end (int arr[][2], int N)
{
	int max = arr[0][1];
	for (int i =1; i<N; i++)
	{
		if (arr[i][1] > max)
			max = arr[i][1];
	}
	
	return max;
}

int findMin_start (int arr[][2], int N)
{
	int min = arr[0][1];
	for (int i =1; i<N; i++)
	{
		if (arr[i][0] < min)
			min = arr[i][0];
	}
	
	return min;
}

int countElements(int arr[][2], int N, int end, int start)
{
	int count=-1;
	for (int i =0; i<N; i++)
	{
		if (arr[i][0]>= start && arr[i][1]<= end)
			count++;
	}
	
	return count;
}

int giveGuest(int arr[][2], int N)
{

	int max_end = findMax_end(arr, N);
	int max_start = findMin_start(arr, N);
//	cout<<max_end<<endl<<max_start;
	int var = countElements(arr, N, max_end, max_start);
	
//	cout<<endl<< var;
	return var;
}


int main (void)
{
	int arr[6][2] = {{1120, 1159}, {1508, 1529}, {1508, 1527}, {1503, 1600}, {1458, 1629}, {1224, 1313}};
	int N = 6;
	int num = giveGuest(arr, N);
	cout<< num;
	return 0;
}

