#include <iostream>
#include <algorithm>
using namespace std;

void swap (int &a, int &b)
{
	int temp = a;
	a = b;
	b = temp;
}

void heapify(int arr[],int n,int i)
{
	// 0 based indexing
	int largest=i;
	int left_child=2*i +1;
	int right_child=2*i+2;

	if(arr[left_child]>arr[largest] && left_child<n)
	{
		largest=left_child;
	}
	if(arr[right_child]>arr[largest] && right_child<n)
	{		
		largest=right_child;
	}

	if(largest != i)
	{
		swap(arr[i],arr[largest]);
		heapify(arr,n,largest);
	}
}


void giveNearest (int a[], int N, int X, int K)
{
	for (int i=0; i<N; i++)
	{
		// deduct distance - house num
		a[i] = a[i]-X; 
	}
	
	// heapify - max
	int last_no_leaf=N/2;

	int i;
	for(i=last_no_leaf;i>=0;i--) // traversing from K+1 to N
		heapify(a,N,i);
		
	// k closest elements
	for (int i=N-1; i>=N-K; i--){
		cout<< a[i]+X<<" ";
	}	
		
}

int main (void)
{
	int N= 5;
	int X = 0;
	int K = 4;
	int a[]= {-21, 21, 4, -12, 20};
	
	giveNearest(a, N, X, K);
	return 0;
}
