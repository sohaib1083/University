#include <iostream>
using namespace std;


class node {
	public:
	char data;
	node * next;
	bool opt;
	node ()
	{
		opt = 0;
		data;
		next = NULL;
	}
	node (char ch)
	{
		opt =isoperator(ch);
		cout<< opt<< endl;
		data = ch;
		next = NULL;
	}
	bool isoperator (char ch)
	{
		if (ch == '+' || ch == '-' || ch == '*' || ch == '/')
			return 1;
			
		return 0;	
	}
};

Node * postfix2infix(node * root)
{
	node * temp = root;
	int arr[100];
	int i=0;
	while (temp != NULL)
	{
		arr[i]= temp->data;
		temp = temp ->next;
	}
	
	if (temp == NULL)
	{
		for (int j= i; i>0; i--)
		{
			cout<< arr[i]<<" ";
			root->data = arr[i];
			root = root->next;
		}
	}
}


int main (void)
{
	node * root = new node ('a');
	root->next = new node ('b');
	root ->next ->next = new node ('+');
	
	postfix2infix(root);
	return 0;
}
