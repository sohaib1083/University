#include<stdio.h>

struct Process {
    int bt; // Burst Time
    int art; // Arrival Time
    int rt; // Remaining time
    int status; // 0-> not available, 1->ready, 2->completed
    int priority; // me
};


int main()
{
    struct Process p[100];
    int completionTime, i, smallest = 0;
    int remain = 0, t, n, sum_wait = 0, sum_turnaround = 0;
    printf("Enter no of Processes: ");
    scanf("%d", &n);

    for(i = 0; i < n; i++)
    {
        printf("Enter arrival time for Process P%d: ", i + 1);
        scanf("%d", &p[i].art);
        printf("Enter burst time for Process P%d: ", i + 1);
        scanf("%d", &p[i].bt);
        p[i].rt = p[i].bt;
    }

    printf("\n\nProcess\t| Turnaround Time | Waiting Time | Status\n\n");
    for(t = 0; remain != n; t++)
    {
        smallest = -1;
        for(i = 0; i < n; i++)
        {
            if(p[i].art <= t && p[i].rt && (smallest == -1 || p[i].rt < p[smallest].rt))
            {
                p[i].status=1; // ready state
                smallest = i;
            }
        }
        if(smallest == -1)
        {
            continue;
        }
        p[smallest].rt--;
        if(p[smallest].rt == 0)
        {
            p[smallest].status=2;
            remain++;
            completionTime = t + 1;
            printf("P[%d]\t| %d\t\t | %d\t\t | %d\n", smallest + 1, completionTime - p[smallest].art, completionTime - p[smallest].bt - p[smallest].art, p[smallest].status);
            sum_wait += completionTime - p[smallest].bt - p[smallest].art;
            sum_turnaround += completionTime - p[smallest].art;
        }
    }
    printf("\n\nAverage waiting time = %lf\n", sum_wait * 1.0 / n);
    return 0;
}