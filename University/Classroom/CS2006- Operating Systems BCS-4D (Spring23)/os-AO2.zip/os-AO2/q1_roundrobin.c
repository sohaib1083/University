#include <stdio.h>

struct Process
{
    int bt;       // Burst Time
    int art;      // Arrival Time
    int rt;       // Remaining time
    int status;   // 0-> not available, 1->ready, 2->running, 3->completed
    int priority; // me
};

int main()
{
    struct Process p[100];
    int completionTime;
    int i, n, sum_wait = 0, sum_turnaround = 0;
    int quant;
    
    printf("Enter no of Processes: ");
    scanf("%d", &n);

    printf("Enter time quantum: ");
    scanf("%d", &quant);

    for(i = 0; i < n; i++)
    {
        printf("Enter arrival time for Process P%d: ", i + 1);
        scanf("%d", &p[i].art);
        printf("Enter burst time for Process P%d: ", i + 1);
        scanf("%d", &p[i].bt);
        p[i].rt = p[i].bt;
    }

    printf("\n\nProcess\t| Turnaround Time | Waiting Time | Status\n\n");
    int sum=0, y=n;
    int count;
    for (sum = 0, i = 0; y != 0;)
    {
        if (p[i].rt <= quant && p[i].rt > 0) // define the conditions
        {
            sum = sum + p[i].rt;
            p[i].rt = 0;
            count = 1;
            p[i].status=3;
        }
        else if (p[i].rt > 0)
        {
            p[i].status=2; // running
            p[i].rt = p[i].rt - quant;
            sum = sum + quant;
            p[i].status=1; // ready
        }
        if (p[i].rt == 0 && count == 1)
        {
            y--; // decrement the process no.
            completionTime = sum;
            printf("P[%d]\t| %d\t\t | %d\t\t | %d\n", i + 1, completionTime - p[i].art, completionTime - p[i].bt - p[i].art, p[i].status);
            sum_wait += completionTime - p[i].bt - p[i].art;
            sum_turnaround += completionTime - p[i].art;
            count = 0;
        }
        if (i == n - 1)
        {
            i = 0;
        }
        else if (p[i].art <= sum)
        {
            i++;
        }
        else
        {
            i = 0;
        }
    }

    printf("\n Average Waiting Time: \t%f", sum_wait * 1.0 / n);
    printf("\n Average Turn Around Time: \t%f", sum_turnaround * 1.0 / n);
}

