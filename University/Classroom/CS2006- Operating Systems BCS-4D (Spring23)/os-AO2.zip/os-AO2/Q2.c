#include<stdio.h>
#include<unistd.h>
#include<pthread.h>
#include<stdlib.h>
#include<semaphore.h>
#include<time.h>
#include<sys/ipc.h>
#include<sys/types.h>
#include<sys/shm.h>

sem_t semFull;
sem_t semEmpty;
pthread_mutex_t mutexBuffer;

#define buffersize 100
char *shm;
char buffer[buffersize];
float cgpa[buffersize];
int in = 0, out = 0, count = 0, gradeCount=0;


void *consumer(void *arg){
sleep(3);
 while(1){
  sem_wait(&semFull);
  pthread_mutex_lock(&mutexBuffer);
  
  char y=buffer[out];
  float y1 = cgpa[out];
  out=(out+1)%buffersize;
  count--;
  gradeCount--;
  if (count == 0 || gradeCount==0){
	break;
  }	
  
  printf("Consumer: %f %c\n", y1, y);	
  sem_post(&semEmpty);
  pthread_mutex_unlock(&mutexBuffer);
  
  }	
  	
 
}
void *producer1(void *arg){

  float x;
  FILE *fp;
  fp=fopen("text.txt", "r");
  
  for(int i=0;i<10;i++){
  sem_wait(&semEmpty);
  pthread_mutex_lock(&mutexBuffer);
  
  fscanf(fp,"%f", &x);
  printf("got %f from file\n", x);
  cgpa[in]=x;
  in=(in+1)%buffersize;
  count++;
  
  sem_post(&semFull);
  pthread_mutex_unlock(&mutexBuffer);
  }
  fclose(fp);
  
}
void *producer2(void *arg){

sleep(1);
in=0;
 while (1)
 {
  sem_wait(&semEmpty);
  pthread_mutex_lock(&mutexBuffer);
  
 for (int i=0; i<10; i++){
  if (cgpa[in] >= 3){
	buffer[in] = 'A';
	printf("adding A grade to the buffer\n");
  }
  else if (cgpa[in] >= 2 && cgpa[in] < 3){
  	buffer[in] = 'B';
	printf("adding B grade to the buffer\n");
  }
  else if (cgpa[in] >= 1 && cgpa[in] < 2){
	buffer[in] = 'C';
	printf("adding C grade to the buffer\n");
  }
  else{
  	buffer[in] = 'D';
	printf("adding D grade to the buffer\n");
  }		
  in=(in+1)%buffersize;
  gradeCount++;
  pthread_mutex_unlock(&mutexBuffer);
  sem_post(&semFull);
  }
  break;
  //sleep(1);
  }
 }


void die(char *c){
printf("Error bhaijan");
 perror(c);
 exit(1);
}


int main(){
   int shmid;
   
   if((shmid=(shmget((key_t)1122, 1024, 0666|IPC_CREAT)))<0){
    die("shmid");
   }
   printf("Key of shared memory is %d\n",shmid);
   if((shm=(char *)(shmat(shmid, NULL, 0)))==(void*)-1){
     die("shm");
   }
   printf("Process attached at %p\n",shm); //this prints the address where the segment is attached
   
   
   for(int i=0;i<buffersize;i++){
     shm[i] = 0;
   }
   pthread_t prod1, prod2, cons1, cons2, cons3, cons4, cons5;
   
    sem_init(&semFull, 0, 0);
    sem_init(&semEmpty, 0, buffersize);
    pthread_mutex_init(&mutexBuffer, NULL);

    pthread_create(&prod1, NULL, producer1, NULL);
    pthread_create(&prod2, NULL, producer2, NULL);
    // 5 threads for consumer
    pthread_create(&cons1, NULL, consumer, NULL);
    pthread_create(&cons2, NULL, consumer, NULL);
    pthread_create(&cons3, NULL, consumer, NULL);
    pthread_create(&cons4, NULL, consumer, NULL);
    pthread_create(&cons5, NULL, consumer, NULL);

    pthread_join(prod1, NULL);
    pthread_join(prod2, NULL);
    pthread_join(cons1, NULL);
    pthread_join(cons2, NULL);
    pthread_join(cons3, NULL);
    pthread_join(cons4, NULL);
    pthread_join(cons5, NULL);

    sem_destroy(&semFull);
    sem_destroy(&semEmpty);
    pthread_mutex_destroy(&mutexBuffer);

return 0;
}
