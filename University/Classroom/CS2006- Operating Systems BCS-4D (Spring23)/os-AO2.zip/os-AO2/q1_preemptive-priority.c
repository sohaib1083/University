#include <stdio.h>
#define MIN 99999;
struct Process
{
    int bt;       // Burst Time
    int art;      // Arrival Time
    int rt;       // Remaining time
    int status;   // 0-> not available, 1->ready, 2->completed
    int priority; // me
    int ct;
    int wt, tat;
    int p_copy;
};
void main()
{
    int i, n, c=0, remaining, min_val, min_index;
    struct Process p[10], temp;
    float avgtat = 0, avgwt = 0;

    printf("Enter no of Processes: ");
    scanf("%d", &n);
    
    for(i = 0; i < n; i++)
    {
        printf("Enter arrival time for Process P%d: ", i + 1);
        scanf("%d", &p[i].art);
        printf("Enter burst time for Process P%d: ", i + 1);
        scanf("%d", &p[i].bt);
        printf("Enter priority for Process P%d: ", i + 1);
        scanf("%d", &p[i].priority);
        p[i].rt = p[i].bt;
        p[i].p_copy = p[i].priority;
    }
    
    remaining = n;

    // sort
    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - i - 1; j++)
            if (p[j].art > p[j + 1].art)
            {
                temp = p[j];
                p[j] = p[j + 1];
                p[j + 1] = temp;
            }

    while (remaining > 0)
    {
        min_val = p[0].priority, min_index = 0;
        for (int j = 0; j < n && p[j].art <= c; j++)
            if (p[j].priority < min_val)
                min_val = p[j].priority, min_index = j;
        i = min_index;
        p[i].ct = c = c + 1;
        p[i].rt--;
        if (p[i].rt == 0)
        {
            p[i].status=3; // completed
            p[i].priority = MIN;
            remaining--;
        }
    }

    printf("\nProcessNo\tAT\tBT\tPri\tStatus\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++)
    {
        p[i].tat = p[i].ct - p[i].art;
        avgtat += p[i].tat;
        p[i].wt = p[i].tat - p[i].bt;
        avgwt += p[i].wt;
        printf("P%d\t\t%d\t%d\t%d\t%d\t%d\t%d\t%d\n", i+1, p[i].art, p[i].bt, p[i].p_copy, p[i].status,p[i].ct, p[i].tat, p[i].wt);
    }
    avgtat /= n, avgwt /= n;
    printf("\nAverage TurnAroundTime=%f\nAverage WaitingTime=%f", avgtat, avgwt);
}