#include <stdio.h> 
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

sem_t database;

int num =10;
void * ticket (void * args)
{
	int c = *(int*) args;
	printf("seller %d entered the data base\n", c);
	while (num > 2)
	{
		sem_wait(&database);
		num--;
		printf("seller %d sold the ticket\n", c);
		sem_post(&database);
	}
	
	printf("seller %d left the data base\n", c);
}

int main (void)
{
	sem_init(&database, 0, 1);
	
	pthread_t sellers[10];
	int cust_num[10];
	for (int i=0; i<3; i++){
		cust_num[i]=i+1;
	}	
	
	for (int i=0; i<3; i++){
		pthread_create(&sellers[i], NULL, &ticket, (void *)&cust_num[i]);
	}
	
	for (int i=0; i<3; i++){
		pthread_join(sellers[i], NULL);
	}
	
	printf("All tickets sold\n");
	return 0;
}
