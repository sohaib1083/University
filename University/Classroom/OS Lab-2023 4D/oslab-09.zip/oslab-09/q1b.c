#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include <unistd.h>
int i_remaining = 10;
sem_t mutex;
void *eat_icecream(void *arg) {
    int *wallet = (int*) arg;
    while (i_remaining > 1) {
        sleep((rand() % 2) + 1);
        if (*wallet <= 0){
        	break;
       } 	
        sem_wait(&mutex); 
        
        i_remaining--;
        printf("Thread %ld purchased an ice cream for $1 with $%d from their wallet. %d ice creams remaining.\n", pthread_self(), *wallet, i_remaining);
        *wallet = *wallet -1;
        //printf("The remaining balance is: %d\n", *wallet);
        sem_post(&mutex); 
    }   
}
int main() {
    sem_init(&mutex, 0, 1);

    srand(time(NULL)); 
    int wallets[3] = {10, 5, 2}; 

    pthread_t threads[3];
    int i;
    for (i = 0; i < 3; i++) {
        pthread_create(&threads[i], NULL, eat_icecream, &wallets[i]);}
    for (i = 0; i < 3; i++) {
        pthread_join(threads[i], NULL);}
    return 0;
}

