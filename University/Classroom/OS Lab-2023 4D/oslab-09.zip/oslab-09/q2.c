#include <stdio.h> 
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

sem_t w, check, pass;

int num =10;
void * airport (void * args)
{
	int *c = (int*) args;
	
	printf("person %d arrived at airport\n", *c);
	
	sem_wait(&w);
	//weight
	printf("person %d getting weighed\n", *c);
	sleep(4);
	sem_post(&w);
	
	sem_wait(&check);
	//checking
	printf("person %d getting checked\n", *c);
	sleep(7);
	sem_post(&check);
	
	sem_wait(&pass);
	//boarding pass
	printf("person %d getting pass\n", *c);
	sleep(3);
	sem_post(&pass);
	
	num--;
	printf("person %d left airport\n", *c);
}

int main (void)
{
	sem_init(&w, 0, 1);
	sem_init(&check, 0, 1);
	sem_init(&pass, 0, 1);
	
	pthread_t customers[10];
	int cust_num[10];
	for (int i=0; i<10; i++){
		cust_num[i]=i+1;
	}	
	
	for (int i=0; i<10; i++){
		pthread_create(&customers[i], NULL, &airport, (void *)&cust_num[i]);
	}
	
	for (int i=0; i<10; i++){
		pthread_join(customers[i], NULL);
	}
	
	printf("All customers done\n");
	return 0;
}
