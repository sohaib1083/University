#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <string.h>

int main (void)
{
	int shmid;
	int * shared_memory;
	shmid = shmget(2984, 1024, 0666|IPC_CREAT);
	shared_memory = (int *)shmat(shmid, NULL, 0);
	*shared_memory = 0;
	return 0;
}
