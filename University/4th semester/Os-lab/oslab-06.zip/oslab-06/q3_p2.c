#include <stdio.h>
#include <unistd.h>
#include <sys/shm.h>
#include <string.h>
#include <stdlib.h>
int main (void)
{
	void * shared_memory;
	char buffer[100];
	int shmid;
	shmid = shmget((key_t)1122, 1024, 0666);
	shared_memory = shmat(shmid, NULL, 0);
	sleep(1);
	printf("Data read by process %d is: %s\n", getpid(), (char *)shared_memory);
	int num=0;
	num = atoi(shared_memory);
	printf("program 2 stored the number %d as int\n", num);
	//sleep(2);
	strcpy(shared_memory, "ready");
	printf("program 2 wrote 'ready' in the shared memory\n");
	sleep(2);
	for (int i=1; i<=10; i++)
	{
		printf("%d x %d = %d\n", i, num, i*num);
	}
	return 0;
}
