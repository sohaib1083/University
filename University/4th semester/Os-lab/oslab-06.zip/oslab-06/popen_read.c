#include <stdio.h>
#include <string.h>
#include <unistd.h>
int main (void)
{
	FILE * file1;
	char buffer[50];
	file1 = popen("ls", "r");
	fread(buffer, sizeof(char), 20, file1);
	write(1, buffer, 20);
	printf("\n");
	pclose(file1);
	return 0;
}

