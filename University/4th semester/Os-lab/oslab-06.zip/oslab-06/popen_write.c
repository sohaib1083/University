#include <stdio.h>
#include <string.h>

int main (void)
{
	FILE * sohaib_file;
	char buffer[50];
	strcpy(buffer, "Hello, this is Sohaib"); //21 characters
	sohaib_file = popen("wc -c", "w"); // print the numbers of character in message
	fwrite(buffer, sizeof(char), strlen(buffer), sohaib_file);
	pclose(sohaib_file);
	return 0;

}
