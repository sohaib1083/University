#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
int main (void)
{
	int r;
	r = open("sohaib_pipe", O_WRONLY);
	write(r, "Hello, this is Sohaib", 21);
	printf("Sender with pid = %d sent the data\n", getpid());
	close(r);
	return 0;
}
