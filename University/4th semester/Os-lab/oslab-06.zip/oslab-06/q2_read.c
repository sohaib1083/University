#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>

int main (void)
{
	sleep(3);
	int f;
	f = fork();
	if (f == 0)
	{
		fork();
	}
	int r, n;
	char buffer[50];
	r = open("sohaib_pipe", O_RDONLY);
	n = read(r, buffer, 50);

	fflush(stdin);
	printf("The data received by process = %d is: \n", getpid());
	fflush(stdin);
	write(1, buffer, n);
	printf("\n");
	fflush(stdin);
	close(r);
	if (f > 0)
	{
		wait(NULL);
	}
	return 0;
}
