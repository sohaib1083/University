#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main (void)
{
	int shmidA, shmidB;
	char buffer[50];
	int * memoryA;
	int * memoryB;
	int num = 0;
	printf("Enter n:");
	scanf("%d", &num);

	shmidA=shmget(2984, 1024, 0666|IPC_CREAT);
	memoryA= (int *)shmat(shmidA, NULL, 0);
	printf("\n%d\n", *memoryA);

	shmidB=shmget(2985, 1024, 0666|IPC_CREAT);
	memoryB= (int *)shmat(shmidB, NULL, 0);
	printf("%d\n", *memoryB);

	int sum;
	for (int i=0; i<num; i++)
	{
		sum = *memoryA + *memoryB;
		*memoryA = *memoryB;
		*memoryB = sum;
		printf("%d\n", sum);
	}
	printf("\n");
	return 0;
}
