#include <stdio.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <string.h>
int main (void)
{
	void *shared_memory;
	char buffer[50];
	int shmid;
	int n;
	shmid = shmget((key_t)1122, 1024, 0666|IPC_CREAT);
	shared_memory = shmat(shmid, NULL, 0);	// 2nd as NULL and 3rd as 0
	strcpy(buffer, "6");
	strcpy(shared_memory, buffer);
	fflush(stdin);
	printf("Program 1 and process %d wrote %s\n", getpid(), buffer);
	fflush(stdin);

	sleep(2);
	strcpy(buffer, shared_memory);
	write(1, buffer, n);
	printf("\nprogram 1 takes in ready as printed above\n");
	strcpy(buffer, "*");
	strcpy(shared_memory, buffer);
	sleep(2);
	return 0;
}
