#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>

int main (void)
{ // blocked mode + named pipe
	int m;
	m = mkfifo("sohaib_pipe", 0777); // name and permissions
	if (m < 0)
	{
		printf("failed\n");
	}
	else{
		printf("named pipe created successfully\n");
	}
	return 0;
}
