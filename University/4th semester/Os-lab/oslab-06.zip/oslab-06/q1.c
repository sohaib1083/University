#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/wait.h>

int main (void)
{
	int fd[2], n;
	// fd 1 -> writing end
	// fd 0 -> reading data
	char buffer[50];
	pipe(fd);
	int f = fork();


	if (f > 0)
	{
		sleep(3);
		fflush(stdin);
		printf("unamed_pipe [INFO] Parent with pid = %d receiving data\n", getpid());
		n = read(fd[0], buffer, 50);
		write(1, buffer, n);
		printf("\n");
	}
	if (f == 0)
	{
		printf("Child with pid = %d sending data\n", getpid());
		write(fd[1], "This is my data", 15);
	}
	if (f>0)
		wait(NULL);
	return 0;
}

