#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <string.h>

int main (void)
{
	int shmid;
	int * shared_memory2;
	shmid = shmget(2985, 1024, 0666|IPC_CREAT);
	shared_memory2 = (int *)shmat(shmid, NULL, 0);
	*shared_memory2 =1;
	return 0;
}

