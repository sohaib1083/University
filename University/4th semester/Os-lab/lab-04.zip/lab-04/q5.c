#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main (void)
{
int pid, count=0;
printf("Enter 0 if you want to to terminate or any other key: ");
while (1)
{
int n;
	scanf("%d", &n);
	
	printf("\n");
	if (n==0){
		break;
	}
	
	pid = fork();
	if (pid == 0)
	{
		printf("Made a new child process with PID = %d\n", getpid());
		count++;
		exit(0);	
	}
}

printf("Exiting..\n");
return 0;
}
