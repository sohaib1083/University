#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    int pid, status;

    for (int i = 0; i < 4; i++) {
        pid = fork();
        if (pid == -1) {
            printf("Failed to create child process\n");
            exit(1);
        }
        else if (pid == 0) {
            printf("Child process %d with PID %d started\n", i+1, getpid());
            sleep(5); // Sleep for 5 seconds to simulate some work
            printf("Child process %d with PID %d finished\n", i+1, getpid());
            exit(0);
        }
    }

    for (int i = 0; i < 4; i++) {
        pid = wait(NULL);
        printf("Waited for child process %d with PID %d\n", i, pid);
    }

    printf("All child processes have terminated\n");
    return 0;
}

