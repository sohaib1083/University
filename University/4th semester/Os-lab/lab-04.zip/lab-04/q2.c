#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <wait.h>

int main(void) {
    int n;
    printf("Enter n number of child process: ");
    scanf("%d", &n); 
    int x;

    for (int i = 0; i < n; i++) {
        x = fork();

        if (x < 0) {
            printf("Fork failed\n");
            exit(1);
        } 
        else if (x == 0) {
            printf("Child process %d with ID %d created by parent process with ID %d\n", i, getpid(), getppid());
            exit(0);
        }
    }

    for (int i = 1; i <= n; i++) {
        wait(NULL);
    }

    return 0;
}

