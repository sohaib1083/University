#include <stdio.h>
#include <unistd.h>
#include <wait.h>
#include <stdlib.h>

int main (void)
{

int pid1, pid2, pid3;

pid1 = fork();

if (pid1 == 0){
	printf("Child process 1 starts\n");
	sleep(10);
	printf("Child process 1 terminates\n");
	exit(0);
}

pid2 = fork();

if (pid2 == 0){
	printf("Child process 2 starts\n");
	sleep(5);
	printf("Child process 2 terminates\n");
	exit(0);
}

pid3 = fork();

if (pid3 == 0){
	printf("Child process 3 starts\n");
	printf("Child process 3 terminates\n");
	exit(0);
}

printf("Parent process starts\n");
waitpid(pid1, NULL, 0);
waitpid(pid2, NULL, 0);
waitpid(pid3, NULL, 0);
printf("parent process terminates\n");
return 0;
}

