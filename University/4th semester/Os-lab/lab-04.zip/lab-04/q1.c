#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

int main (void)
{

    int i = fork();
    
    if (i < 0){
   	 printf("Unsuccessful Child Process Creation");
   	 exit(0);
    }
    if (i > 0){
    	sleep(1);
    	printf("I'm in parent's process\n");
    }
    if (i == 0){
    	sleep(5);
    	printf("The parent id is %d.", getppid());
    	printf("\n");
   	 for (int i=1; i<10; i++){
   		 if (i % 2 != 0){
   			 printf("%d  ", i);
   		 }
   	 }
   	 printf("\nChild ends\n");
    }
    
   	 wait(NULL);

    return 0;
}

