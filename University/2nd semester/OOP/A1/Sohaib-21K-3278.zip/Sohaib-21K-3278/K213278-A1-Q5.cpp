#include<iostream>

using namespace std;

class HeartRate{
		string f_name,l_name;
		int day,month,year,age;
	public:
		HeartRate(string fname,string lname,int d,int m,int y){
			f_name = fname;
			l_name = lname;
			day = d;
			month = m;
			year = y;
		}
		void setf_name(string fn){
			f_name = fn;
		}
		void setl_name(string ln){
			l_name = ln;
		}
		void setDOB(int d,int m,int y){
			day = d;
			month = m;
			year = y;
		}
		string getf_name() const{
			return f_name;
		}
		string getl_name() const{
			return l_name;
		}
		int getDay() const {
			return day;
		}
		int getMonth() const{
			return month;	
		}
		int getYear() const {
			return year;
		}
		int getAge(){
			int d,m,y;
			cout<<"\nEnter current date,month and year";
			cin>>d>>m>>y;
			if(m>=month){
				if(d>=day){
					age = y - year;
				}
			} else {
				age = y-year-1;
			}
			return age;
			
		}
		int getMaximumHeartRate(){
			return 220 - age;
		}
		int getTargetHeartRate(){
			return 0.8 * getMaximumHeartRate(); 
		}
		
};
int main(){
	string fname,lname;
	int d,m,y;

	cout<<"Enter your first name: ";
	getline(cin, fname);

	cout<<"Enter last name: ";
	getline(cin, lname);

	cout<<"Enter your DOB(dd/mm/yy): ";
	cin>>d>>m>>y;

    HeartRate obj1(fname,lname,d,m,y);

    system("cls");
    cout<< "\nFirst name: "<< obj1.getf_name()<< "\nLast name: "<< obj1.getl_name()<< "\nDate of birth: "<< obj1.getDay()<< "/"<< obj1.getMonth()<< "/"<< obj1.getYear()<< endl;
    cout<< "Age: " << obj1.getAge();
	cout<< "\nThe maximum heart rate is: " <<obj1.getMaximumHeartRate()<<endl;
	cout<< "The target heart rate is: "<<obj1.getTargetHeartRate();
}