#include<iostream>
#include<string>
#include<iomanip>
#include<cmath>

using namespace std;

class HealthProfile{
	private:
		string f_name,l_name,gen;
		int day,month,year,age;
		float height,weight,BMI;
	public:
		HealthProfile(string fn,string ln,string ge,int d,int m,int y,int h, int w){
			f_name = fn;
			l_name = ln;
			gen = ge;
			day = d;
			month = m;
			year = y;
			height = h;
			weight = w;
		}
		void setf_name(string fn){
			f_name = fn;
		}
		void setl_name(string ln){
			l_name = ln;
		}
		void setDOB(int d,int m,int y){
			day = d;
			month = m;
			year = y;
		}
		void setHeight(float h){
			height = h;
		}
		void setWeight(float w){
			weight = w;
		}
		string getf_name() const{
			return f_name;
		}
		string getl_name() const{
			return l_name;
		}
		int getDay() const {
			return day;
		}
		int getMonth() const{
			return month;	
		}
		int getYear() const {
			return year;
		}
		float getHeight() const {
			return height;
		}
		float getWeight() const {
			return weight;
		}
		int getAge(){
			int d,m,y;
			cout<<"\nEnter current date,month and year";
			cin>>d>>m>>y;
			if(m>=month){
				if(d>=day){
					age = y - year;
				}
			} else {
				age = y-year-1;
			}
			return age;	
		}
		int getMaximumHeartRate(){
			return 220 - age;
		}
		int getTargetHeartRate(){
			return 0.8 * getMaximumHeartRate(); 
		}
		float getBMI(){
			BMI = (703 * weight) / pow(height,2);
			return BMI;
		}
};
int main(){
	string fn,ln,ge;
	int d,m,y;
	float h,w;
	cout<<"Enter first name: ";
	getline(cin,fn);
	cout<<"Enter last name: ";
	getline(cin,ln);
	cout<<"Enter your gender: ";
	cin>>ge;
	cout<<"Enter DOB(d/m/y): ";
	cin>>d>>m>>y;
	cout<<"Enter your height(inches): ";
	cin>>h;
	cout<<"Enter your weight(pounds): ";
	cin>>w;
	HealthProfile obj1(fn,ln,ge,d,m,y,h,w);

    system("cls");
    cout<< "\nFirst name: "<< obj1.getf_name()<< "\nLast name: "<< obj1.getl_name()<< "\nDate of birth: "<< obj1.getDay()<< "/"<< obj1.getMonth()<< "/"<< obj1.getYear()<< endl;
    cout<< "Age: " << obj1.getAge()<< endl;
    cout<< "height: "<< obj1.getHeight()<< endl;
    cout<< "weight: "<< obj1.getWeight()<< endl;
	cout<<"Max heart rate: "<<obj1.getMaximumHeartRate()<<endl;
	cout<<"Target heart rate: "<<obj1.getTargetHeartRate()<<endl;
	cout<<"BMI: "<<obj1.getBMI();
	
}