#include <iostream>
#include <string>
using namespace std;
class Employee
{
    string f_name;
    string l_name;
    int sal;

public:

    Employee()
    {
        f_name = "NONE";
        l_name = "NONE";
        sal = 0;
    }

    void setf(string fn)
    {
        f_name = fn;
    }

    void setl(string ln)
    {
        l_name = ln;
    }

    void set_sal(int ms)
    {
        if (ms < 0)
        {
            sal = 0.0;
        }
        else
        {
            sal = ms;
        }
    }

    void getf()
    {
        cout << "First Name: " << f_name << endl;
    }

    void getl()
    {
        cout << "Last Name: " << l_name << endl;
    }

    int get_sal()
    {
        return sal;
    }
};

int get_yearly_sal(int ms)
{
    return (12 * ms);
}

int rasie(int ys)
{
    ys = ys + (0.10 * ys);
    return ys;
}

int main()
{
    Employee obj1, obj2;
    string fname, lname;
    int msal, ysal1, ysal2, r1, r2;

    cout << "Employee 1: " << endl;
    cout << "Enter the first name: ";
    getline(cin, fname);
    obj1.setf(fname);
    
    cout << "Enter the last name: ";
    getline(cin, lname);
    obj1.setl(lname);
    
    cout << "Enter the monthly salary: ";
    cin >> msal;
    obj1.set_sal(msal);
    
    ysal1 = get_yearly_sal(msal);
    r1 = rasie(ysal1);

    cout << "Employee 2: " << endl;
    cout << "Enter the first name: ";
    fflush(stdin);
    getline(cin, fname);
    obj2.setf(fname);
    
    cout << "Enter the last name: ";
    getline(cin, lname);
    obj2.setl(lname);
    
    cout << "Enter the monthly salary: ";
    cin >> msal;
    obj2.set_sal(msal);
    
    ysal2 = get_yearly_sal(msal);
    r2 = rasie(ysal2);

    system("cls");
    cout << "Employee 1: " << endl;
    obj1.getf();
    obj1.getl();
    cout << "Yearly salary: " << ysal1 << endl;
    cout << "Salary after 10% increment: " << r1 << endl;

    cout << "\n\nEmployee 2: " << endl;
    obj2.getf();
    obj2.getl();
    cout << "Yearly salary: " << ysal2 << endl;
    cout << "Salary after 10% increment: " << r2 << endl;
}
