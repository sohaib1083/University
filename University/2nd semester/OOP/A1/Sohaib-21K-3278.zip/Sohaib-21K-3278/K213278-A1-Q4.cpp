# include <iostream>

using namespace std;

class Date{
    int month; 
    int day;
    int year;

    public:
    Date (int m, int d, int y)
    {
        year = y;
        day = d;
        if (m >= 1 && m <= 12){
            month = m;
        }
        else{
            cout<< "Not in range."<< endl;
            month = 1;
        }
    }
    void setm (int m)
    {
        month = m;
    }
    void setd (int d)
    {
        day = d;
    }
    void sety (int y)
    {
        year = y;
    }
    int getd (void)
    {
        return day;
    }
    int getm (void)
    {
        return month;
    }
    int gety (void)
    {
        return year;
    }
    void displayDate (void)
    {
        cout<< day<< "/"<< month<< "/"<< year<< endl;
    }
};

int main (void)
{
    Date test(11, 9, 2002);
    int d, m, y;

    test.displayDate();

    cout<< "Enter new date:";
    cin>> d;
    test.setd(d);

    cout<< "Enter new month:";
    cin>> m;
    test.setm(m);

    cout<< "Enter new year:";
    cin>> y;
    test.sety(y);

    test.displayDate();

    return 0;
}

