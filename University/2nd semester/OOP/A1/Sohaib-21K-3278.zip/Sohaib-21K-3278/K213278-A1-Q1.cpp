#include <iostream>
using namespace std;

class customer{
    int balance;

    public:
    customer (int x)
    {
        if (x >= 0){
            balance = x;
        }
        else {
            balance = 0;
            cout<< "Initial balance was invalid"<< endl;
        }
    }
    void credit (int a)
    {
        balance = balance + a;
    }
    void debit (int a)
    {
        if (a > balance){
            cout<< "Debit amount exceeded account balance\n";
        }
        else{
        balance = balance - a;
        }
    }
    float getBalance (void)
    {
        return balance;
    }
};

int main (void)
{
    int b;

    cout<< "Enter balance for first customer:";
    cin>> b;
    customer obj1(b);

    cout<< "Enter credit amount:";
    cin>> b;
    obj1.credit(b);

    cout<< "Enter debit amount:";
    cin>> b;
    obj1.debit(b);

    cout<< "The leftover balance is : "<< obj1.getBalance()<< endl;

    // second object
    cout<< "Enter balance for second customer:";
    cin>> b;
    customer obj2(b);

    cout<< "Enter credit amount:";
    cin>> b;
    obj2.credit(b);

    cout<< "Enter debit amount:";
    cin>> b;
    obj2.debit(b);

    cout<< "The leftover balance is : "<< obj2.getBalance()<< endl;
    return 0;
}