#include<iostream>
using namespace std;

class customer{
	string f_name, l_name, current_city;
	const int NIC;
	float annual_income;
	bool tax_filer;	
	
	public:	
	customer(int n) : NIC{n}
	{
		f_name = "Customer ";
		l_name = "one";
		current_city = "Karachi";
		annual_income = 2738;
		tax_filer = false;	
	}
	
	void getInput()
	{
		float loan;
			cout<< "Enter first name: ";
			cin>> f_name;
			
			cout<< "Enter last name: ";
			cin >> l_name;
			
			cout<< "Enter current city: ";
			cin >> current_city;
			
			cout << "Annual income: ";
			cin >> annual_income;
			
			char c;
			cout<< "Are you income tax filer? (Y/N)";
			cin>> c;
			
			if (c == 'Y')
			{
				tax_filer = true;
			}
			else{
				tax_filer = false;
			}			
	}
	
	string get_city()
	{
		return current_city;
	}
	float get_income()
	{
		return annual_income;
	}
	
};



class branch{
	string city, supervisor;
	int branch_code;
	float interest_rate;
	static double total_loan;
	
	public:
	branch (string c, string s, int b, float i)
	{
		city = c;
		supervisor = s;
		branch_code = b;
		interest_rate = i;
	}
	branch()
	{
		
	}
	
	int issue_loan(double loan_req)
	{
		int n;
		
		cout<< "Enter NIC: ";
		cin>>n;
		customer c(n);
		
		c.getInput();
		
		if (loan_req <= c.get_income() && city == c.get_city())
		{
			cout<< "Loan request approved";
			total_loan += loan_req;
			return 1;
		}
		else
		{
			cout<< "Loan request not approved";
			return -1;
		}
		
	}
	
	void loan_calculator(double loan_req)
	{
	    float payable = loan_req + ((loan_req * interest_rate/100));
	    cout<< "\nThe total amount payable is: "<< payable;	
		
	}
	
	static void print_total()
	{
		cout<< "\nTotal loan provided is : "<< total_loan<< ".";
	}
};

double branch :: total_loan = 0; 


	
int main (void)
{
	
    branch B1("Karachi", "Raheem", 3245, 1.5);
    branch B2("Lahore", "Abdullah", 3242, 2);
    branch B3("Islamabad", "Sohaib", 5243, 3.5);

    branch obj1(B1);
    
    double loan_req;
    cout<< "Enter loan requested: ";
    cin>> loan_req;
	int result = B1.issue_loan(loan_req);
	if (result == -1)
	{
		
	}
	else{
	B1.loan_calculator(loan_req);	
	}
	
	B1.print_total();
			
	return 0;
}
