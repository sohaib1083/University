#include <iostream>
#include <fstream>
using namespace std;

class CarbonFootprint
{
    protected:
        string source;
        double b, oth;

    public:
        virtual double GetCFP() = 0;
};

class Building : protected CarbonFootprint
{
    private:
        string name;
        int floors;
        string type;

    public:
        Building(string n, int f, string t)
        {
            name = n;
            floors = f;
            type = t;
        }

        double GetCFP()
        {
            cout << "primary heating source: ";
            cin >> source;
            cout << "monthly bill: ";
            cin >> b;
            cout << "other: ";
            cin >> oth;

            return (b + oth); 
        }
};

class Car : protected CarbonFootprint
{   
    private:
        string fuel, model;
        int engine;
    
    public:
        Car(string f, string m, int s)
        {
            fuel = f;
            model = m;
            engine = s;
        }

        double GetCFP()
        {
            cout << "primary heating source: ";
            cin >> source;
            cout << "monthly bill: ";
            cin >> b;
            cout << "other:";
            cin >> oth;

            return (b +oth); 
        }
};

class Bicycle : protected CarbonFootprint
{
    private:
        string type;
        float time, cost;

    public:
        Bicycle(string t, float time, float c)
        {
            type = t;
            this->time = time;
            cost = c;
        }

        double GetCFP()
        {
            cout << "heating source: ";
            cin >> source;
            cout << "monthly bill: ";
            cin >> b;
            cout << "other: ";
            cin >> oth;

            return (b+oth); 
        }
};

int main()
{
    Building b1("Parca mall", 9, "Resedential");
    Car c1("Electric", "Etron", 590);
    Bicycle B1("Hybrid", 18, 490);

    ofstream file;

    file.open("CarbonFootprint.dat", ios :: out);
    if(file.is_open())
    {
        file << b1.GetCFP() << endl;
        file << c1.GetCFP() << endl;
        file << B1.GetCFP() << endl;
    }
    else
    {
        cout << "Error!";
    }

    file.close();

    return 0;   
}
