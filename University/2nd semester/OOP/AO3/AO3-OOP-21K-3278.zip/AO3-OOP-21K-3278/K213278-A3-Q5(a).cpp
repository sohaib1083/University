#include <iostream>
#include <fstream>

using namespace std;

class abc{
	int a;
	float b;
	string c;
	public:
	abc(int a, float b, string c) : a(a), b(b), c(c)
	{
		
	}
		
	void writingData(abc obj1)
	{
		ofstream file;
		file.open("XYZ.txt", ios :: app);
		file.write((char *)&obj1, sizeof(obj1));
		file.close();
		
	} 
	
	void readingData(abc obj1)
	{
	    ifstream file1;
		file1.open("XYZ.txt", ios :: in);
		while(!file1.eof())
		{
		file1.read((char *)&obj1, sizeof(obj1));	
		}	
	}	
};

int main (void)
{
	abc obj1(1, 2.3, "Sohaib");
	obj1.writingData(obj1);
	obj1.readingData(obj1);
	return 0;
}
