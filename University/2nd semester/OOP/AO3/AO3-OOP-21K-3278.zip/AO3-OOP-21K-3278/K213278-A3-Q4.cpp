#include <iostream>
using namespace std;

class CounterStaff;
class pharmacist;

class meds{
	protected:
	string name, formula, m_date, e_date;
	double retail_price;
	
	
	public:
	meds(string n, string f, string m, string e, double r)
	{
		name = n;
		formula = f;
		m_date = m;
		e_date = e;
		retail_price = r;
	}
	meds()
	{
		
	}
	
	public:
		
	void operator ==(meds &m2)
	{
		
		if (e_date.substr(6, 4) == m2.e_date.substr(6, 4))
		{
			cout<< "same year expiry"<< endl;
		}		
	}
	
	void search_med()
	{
		cout<< "over-ridden func";
	}	
	
	friend class pharmacist;
	friend class CounterStaff;
};

class tablets : protected meds{
	float sucrose_level;
	
};

class capsules : protected meds{
	float absorbtion_precent;
};

class syrups : protected meds{
	
};


class pharmacist: protected meds{
	
	public:
//	meds m("Rigix", "CH2", "21/12/2002", "21/12/2012", 12.3);		
		
	void search_med(meds &m1)
	{
		string f;
		cout<< "Enter formula: ";
		cin>> f;
		
		if (f == m1.formula)
		{
			cout<<"The details for med is as follows: ";
			cout<< m1.name << endl<< m1.formula << endl<< m1.e_date<< endl<< m1.m_date<< endl<< m1.retail_price;
		}
		else{
			cout<< "not found";
		}
	}
};


class CounterStaff : protected meds{
	public:
	void search_med(meds &m1)
	{
		string n;
		cout<< "\nEnter name: ";
		cin>> n;
		
		if (n == m1.name)
		{
			cout<<"The details for med is as follows: ";
			cout<< m1.name << endl<< m1.formula << endl<< m1.e_date<< endl<< m1.m_date<< endl<< m1.retail_price;
		}
		else{
			cout<< "not found";
		}
	}
};


int main (void)
{
	meds m1("Rigix", "CH2", "21/12/2002", "21/12/2012", 12.3), m2("Travegel", "CHO", "18/12/2003", "21/12/2012", 51.45);
	m1.operator ==(m2);
	
	pharmacist p1;
	p1.search_med(m1);
	
	CounterStaff c1;
	c1.search_med(m2);
	
	
	return 0;
}
