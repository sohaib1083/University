#include <iostream>
#include <fstream>

using namespace std;

class abc{
	int a;
	float b;
	string c;
	public:
	abc(int a, float b, string c) : a(a), b(b), c(c)
	{
		
	}
		
	void writingData()
	{
		ofstream file;
		file.open("XYZ.txt", ios :: app);
		file << a<< endl;
		file << b<< endl;
		file << c<< endl;
		file.close();
		
	} 
	
	void readingData()
	{
	    ifstream file1;
	    string line;
		file1.open("XYZ.txt", ios :: in);
		if (file1.is_open())
		{
			while (getline(file1, line))
			{
				cout<< line << "\n";
			}
			file1.close();
		}
		else{
			cout<< "unable to open the file";
		}
	}	
};

int main (void)
{
	abc obj1(1, 2.3, "Sohaib");
	obj1.writingData();
	obj1.readingData();
	return 0;
}
