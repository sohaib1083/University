#include <iostream>
#include <string>
using namespace std;

class cloth
{
    protected:
        string ID;
        static double rev;
        static double tax;

    public:
        virtual float b() = 0;

        cloth(string d)
        {
            ID = d;
        }
        
        static void tax_calc(float amount, float rate)
        {
            tax += (rate/100)*amount;
        }

        static double get_tax()
        {
            return tax;
        }

        static void rev_calc(float amount)
        {
            rev += amount;
        }

        static double get_rev()
        {
            return rev;
        }
};

class Shirt : virtual public cloth
{
    protected:
        string design;
        float pr;
        static int stock_shirt;

    public:
        Shirt(string d, string ID, float p=1500) : cloth(ID)
        {
            design = d;
            pr = p;
        } 

        float b()
        {
            return pr;
        }

        float b(string code, Shirt s)
        {
            float pr = s.pr - 0.1*s.pr;
            return pr;
        }

        static void calc_stock()
        {
            stock_shirt--;
        }

        static void rev_calc(Shirt &s)
        {
            rev += s.pr;
            tax += 0.7*s.pr;
        }
};

class Pant : virtual public cloth
{
    protected:
        string style;
        float pr;
        static int stock_pant;
    
    public:
        Pant(string s, string ID, float p) : cloth(ID)
        {
            style = s;
            pr = p;
        }
        Pant(Pant &p) : cloth(p.ID)
        {
            style = p.style;
            pr = p.pr;
        }

        float b()
        {
            return pr;
        }
        static void calc_stock()
        {
            stock_pant--;
        }
        static void rev_calc(Pant &p)
        {
            rev += p.pr;
            tax += 0.4*p.pr;
        }
        void operator <(Shirt &p)
        {
            if (pr > p.b())
            {
                cout << "The shirt has provided with more profit.";
            }
            else
            {
                cout << "The Pant has provided with more profit.";
            }
        }
};

class Tie : virtual public cloth
{
    protected:
        string pattern;
        float pr;
        static int stock_tie;

    public:
        Tie(string p, string ID, float pr) : cloth(ID)
        {
            pattern = p;
            pr = pr;
        }
        float b()
        {
            return pr;
        }
        static void calc_stock()
        {
            stock_tie--;
        }
        static void rev_calc(Tie &t)
        {
            rev += t.pr;
        }
};

class Suit : public Shirt, public Pant, public Tie
{
    private:
        float pr;
    
    public:
        Suit(string ID, string s, string p, string t, float p_p, float t_p) : Shirt(s, "2323"), Pant(p, "232", p_p), Tie(t, "531", t_p), cloth(ID)
        {
            pr = 1500 + p_p + t_p;
        }

        float b()
        {
            float suit_pr;
            suit_pr = Shirt :: pr + Pant :: pr + Tie :: pr;
            return suit_pr; 
        }

        void rev_calc()
        {
            rev += pr; 
        }
};

double cloth :: tax=0;
double cloth :: rev=0;
int Shirt :: stock_shirt=10;
int Pant :: stock_pant=9;
int Tie :: stock_tie=8;

int main()
{
    Shirt s1("Eid-collection", "126"), s2("Lahori", "127");
    Shirt :: rev_calc(s1); Shirt :: rev_calc(s2);

    Pant p1("skinny", "124", 1600), p2("", "125", 2000);
    Pant :: rev_calc(p1); Pant :: rev_calc(p2);

    Tie t1("Classic", "123", 500); Tie :: rev_calc(t1);

    Suit Suit1("128", "party-wear", "short", "check", 2000, 700); Suit1.rev_calc();

    p1 < s1;

    cout << "\nTotal revenue: " << cloth :: get_rev();
    cout << "\nTotal tax: " << cloth :: get_tax();

    return 0;
}
