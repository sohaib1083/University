#include<iostream>
using namespace std;

class package{
    protected:
    string name, address, city, state;
    int zip_code_sender, zip_code_receiver;
    float weight, cost; // per ounce

    public:
    package()
    {
        name = "Sohaib";
        address = "Florida homes";
        city = "Karachi";
        state = "Nevada";
        zip_code_receiver = 75500;
        zip_code_sender = 76600;
        weight = 10;
        cost = 10;
        set_weight();
        set_cost();
        // weight and cost > 0
    }

    void set_weight(void)
    {
        cout<< "\nEnter weight: ";
        cin>> weight;
        if (weight > 0)
        {
            this -> weight = weight;    
        }
        else
        {
            while (weight < 0)
            {
                cout<< "\nEnsure weight is greater than 0\nEnter weight: ";
                cin>> weight;
            }
            this -> weight = weight;
        }
    }

    void set_cost(void)
    {
        cout<< "\nEnter cost: ";
        cin>> cost;
        if (cost > 0)
        {
            this -> cost = cost;    
        }
        else
        {
            while (cost < 0)
            {
                cout<< "\nEnsure cost is greater than 0\nEnter cost: ";
                cin>> cost;
            }
            this -> cost = cost;
        }
    }

    virtual double calculateCost()
    {
        return (weight * cost);
    }
};

class TwoDayPackage : public package{
    float fee; // flat

    public:
    TwoDayPackage(float x)
    {
        fee = x;
    }

    double calculateCost()
    {
        return ((fee) + (weight * cost));
    }

};

class OvernightPackage : public package{
    float additional_fee; // per ounce

    public:

    OvernightPackage(int x)
    {
        additional_fee = x;
    }

    double calculateCost()
    {
        return ((additional_fee*weight) + (weight * cost));
    }

};

int main(void)
{
    OvernightPackage obj1(10);
    cout<< obj1.calculateCost()<< endl;

    TwoDayPackage obj2(2);
    cout<< obj2.calculateCost()<< endl;
    return 0;
}