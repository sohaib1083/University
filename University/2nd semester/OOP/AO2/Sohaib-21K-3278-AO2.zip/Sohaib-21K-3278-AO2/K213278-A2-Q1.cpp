#include <iostream>
using namespace std;

class Message{
    string x;
    public:
    Message(string x = "Default argument")
    {
        this -> x = x;
    }

    void print()
    {
        cout<< x<< endl;
    }

    void print(string y)
    {
        cout<< x + y<< endl;
    }
};


int main(void)
{
    Message o1;
    o1.print();
    o1.print(" Hello");

    Message o2("Sohaib");
    o2.print();
    o2.print(" Aayan");

    return 0;
}