#include <iostream>
using namespace std;

class area{
    protected:
    float a, b;
    public:
    area (float a, float b)
    {
        this -> a = a;
        this -> b = b;
    }
};

class print_areas : public area{
    public:
    print_areas(float a, float b) : area(a, b)
    {

    }

    void calc_area(float lenght, float breadth)
    {
        a = lenght;
        b = breadth;
        cout<< "The area of rectangle is: "<< a*b<< endl;
    }
    void calc_area(float lenght)
    {
        a = lenght;
        b = lenght;
        cout<< "The area of square is: "<< a*b<< endl;
    }
};

int main (void)
{
    print_areas obj1(1, 2);
    obj1.calc_area(3, 4); // rectangle
    obj1.calc_area(2); // square
    return 0;
}