#include <iostream>
using namespace std;

class Account{
    protected:
    double balance;
    public:
    Account(double x)
    {
        if (x > 0)
        {
            balance = x;
        }
        else
        {
            balance = 0;
            cout<< "Error. bruhh you entered negative number for balance, you okay? "<< endl;
        }
    }
    void credit (double x)
    {
        balance = balance + x;
    }

    bool debit (double x)
    {
        if (x > balance)
        {
            cout<< "Error. bruhh debit amount exceeded your bank balance"<< endl;
        }
        else
        {
            balance = balance - x;
            return 1;
        }
    }

    void showbalance()
    {
        cout<< "The current balance is: "<< balance<< endl;
    }
};

class savings_account : public Account{
    double interest_rate;

    public:
    savings_account(double interst_rate, double balance) : Account(balance)
    {
        this -> interest_rate = interest_rate;
    }

    double interestRate(void)
    {
        return (interest_rate * balance);
    }
};

class checking_account : public Account{
    double fee;

    public:
    checking_account(double fee, double balance) : Account (balance)
    {
        this -> fee = fee;
    }

    void credit (int x)
    {
        Account :: credit(x);
        balance = balance - fee;
    }

    void debit (int x)
    {
        bool y = Account :: debit(x);
        if (y)
        {
            balance = balance - fee;
        }
    }
};

int main (void)
{
    Account obj1(100);
    obj1.credit(10);
    obj1.debit(20);
    obj1.showbalance();

    savings_account obj2(10, 100);
    double amount = obj2.interestRate();

    checking_account obj3(10, 300);
    obj3.credit(amount);
    obj3.debit(10);
    obj3.showbalance();


    return 0;
}