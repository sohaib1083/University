#include <iostream>
using namespace std;

class base{
    protected:
    float lenght, breadth;
    public:
    base(float lenght, float breadth)
    {
        this -> lenght = lenght;
        this -> breadth = breadth;
    }

    virtual float area (void)
    {
        return (lenght*breadth);
    }


};

class derived : public base{
    public:
    derived(float lenght, float breadth) : base (lenght, breadth)
    {

    }

    float area (void)
    {
        cout<< "I'm in child class"<< endl;
        return (lenght*breadth);
    }

};


int main (void)
{
    derived obj1(12, 10);
    base * ptr = &obj1;

    cout<< ptr ->area();
    return 0;
}