#include <stdio.h>

void increment (int *a, int n)
{
	int i;
	for (i=0; i<n; i++)
	{
		// increment of 2
		*(a+i) = *(a+i) + 2;

	}
}


int main (void)
{
	
	int a[100], size, i;
	
	// asking user for size of array.
	printf("Enter the size of array: ");
	scanf("%d", &size);
	
	// populating array.
	for (i=0; i<size; i++)
	{
		printf("Enter the element %d : ", i+1);
		scanf("%d", (a+i));
	}
	
	printf("****BEFORE INCREMENT******\n\n");
	for (i=0; i<size; i++)
	{
		printf("%d, ", *(a+i));
	}
	
	printf("\n\n\n");
	
	// calling function sort.
	increment(a,size);
	
	
	printf("****AFTER INCREMENT******\n\n");
	for (i=0; i<size; i++)
	{
		printf("%d, ", *(a+i));
	}
	
	
	return 0;
}