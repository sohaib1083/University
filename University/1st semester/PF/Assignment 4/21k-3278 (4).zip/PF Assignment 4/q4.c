#include <stdio.h>

void sort (int *a, int n)
{
	int swap, i, j;
	for (i=0; i<n-1; i++)
	{
		for (j=0; j<n-i-1; j++)
		{
		if (a[j] > a[j+1])
		{
			// swapping.
			swap = a[j];
			a[j] = a[j+1];
			a[j+1] = swap;
		}
	    }
	}
}


int main (void)
{
	
	int a[100], size, i;
	
	// asking user for size of array.
	printf("Enter the size of array: ");
	scanf("%d", &size);
	
	// populating array.
	for (i=0; i<size; i++)
	{
		printf("Enter the element %d : ", i+1);
		scanf("%d", (a+i));
	}
	
	printf("****UNSORTED ARRAY******\n\n");
	for (i=0; i<size; i++)
	{
		printf("%d, ", *(a+i));
	}
	
	printf("\n\n\n");
	
	// calling function sort.
	sort(a,size);
	
	
	printf("****SORTED ARRAY******\n\n");
	for (i=0; i<size; i++)
	{
		printf("%d, ", *(a+i));
	}
	
	
	return 0;
}