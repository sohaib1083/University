#include<stdio.h> 

float Average (float *a){
    float sum;
    
    // adding all 3 marks
    sum = *a + *(a+1) + *(a+2);
    
    return sum/3;
}
float Percentage (float *a){
    float s, per;
    
    // adding all 3 marks
    s = *a + *(a+1) + *(a+2);
    per = (s/300)*100;

    return per;
}
        

int main (void){
    
    float a[10], avg, per;
    int i;
    
    // Taking input for marks out of 100.
    for (i=0; i<3; i++){
       printf("Enter marks for subject %d : ",i+1);
        scanf("%f", &a[i]);
    }
    
    
    // calling respective functions and sending the address for 'a' as parameter.
    avg = Average(a);
    printf("The average is : %.2f\n", avg);
    
    per = Percentage(a);
    printf("The percentage is : %.2f\n", per);
    
    return 0;
}