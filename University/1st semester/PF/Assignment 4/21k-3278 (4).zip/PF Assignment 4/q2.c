#include <stdio.h>

int sum_of_digits (int n)
{
	int sum = 0;
	while (n!=0)
	{
		sum = sum + n%10;
		n = n / 10;
	}
	return sum;
}


int main (void){
	
	int num, sum;
	
	// prompt the user until he enters a 5 digit number. 
	do{
		printf("Enter a 5 digit number: ");
		scanf("%d", &num);
	}while (num >99999 || num <= 9999);
	
	// calling function to calculate sum of digits
	sum = sum_of_digits(num);
	
	printf("The sum of digits is %d.", sum);
	
	return 0;
}