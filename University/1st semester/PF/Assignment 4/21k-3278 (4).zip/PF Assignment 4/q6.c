#include <stdio.h>
#include <math.h>

float plot_area (float a, float b, float angle)
{
	float area;
	
	area = 0.5 * a * b * sin(angle);
	
	return area;
}



int main (void)
{
	
	int i;
	float area, largest;
	
	float a[6] ={137.4, 155.2, 149.3, 160.0, 155.6, 149.7};
	float b[6] = {80.9, 92.62, 97.93, 100.25, 68.95, 120.0};
	float angle[6] = {0.78, 0.89, 1.3, 9.00, 1.25, 1.75};
	
	for (i=0; i<6; i++)
	{
		area = plot_area(a[i], b[i], angle[i]);
		
		if (i == 0){
			largest = area;
		}
		else{
			if (area > largest)
			   largest = area;
		}
		printf("The area for plot no. %d is : %.2f.\n", i+1, area);
		
	}
	
	printf("\n\n");
	
	printf("The maximum value for area is %.2f.", largest);
	
}