#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct library

{
	int accessionNo;
	char title[50];
	char author[50];
	int  cost;
	int flag; // either 0 for off or 1 for on 
}invent[100]; 


// proto-types
void addBookInfo();
void displayBookInfo();
void listAuthor();
void listTitle();
void countBook();
void listAcc();


int main()
{
	int menu;
	
	while (1)
	{
		printf("Enter your choice: \n");
		printf("\t1. Add book information\n\t2. Display book information\n\t3. List all books of given author\n\t4. List the title of specified book\n\t5. List the count of books in the library\n\t6. List the books in the order of accession number\n\t7. Exit\n");
		
		// Taking input for choice
		printf("Enter your choice (1 - 7): ");
		scanf("%d" , &menu);
		
		switch(menu)
		{
			case 1:
				{
					addBookInfo();
					break;
				}
			case 2:
				{
					displayBookInfo();
					break;
				}
			case 3:
				{
					listAuthor();
					break;
				}
			case 4:
				{
					listTitle();
					break;
				}
			case 5:
				{
					countBook();
					break;
				}
			case 6:
				{
					listAcc();
					break;
				}
			case 7:
				{
					printf("ThankYou for using Library!");
					exit(0);
					break;
				}
			default:
			{
				printf("Invalid entry! Re-run!");
				break;
			}
		}
		fflush(stdin);
	}
	
	printf("\n\n");
}

int count;

void addBookInfo()
{
	
    // Adding and storing details.
	printf("Enter the following details of book: \n");
	
	printf("Enter accession number of book: ");
	scanf("%d" , &invent[count].accessionNo);

	fflush(stdin);
	
	printf("Enter the book title: ");
	gets(invent[count].title);
	
	fflush(stdin);
	
	printf("Enter the name of author: ");
	gets(invent[count].author);
	
	fflush(stdin);
	
	printf("Enter the cost of book: ");
	scanf("%d" , &invent[count].cost);
	
	printf("Enter issue status of book 1 for Issues 0 for Not Issued: ");
	scanf("%d"  , &invent[count].flag);
	
	count++;// counter for number of books
	
	printf("\n\n");
}

void displayBookInfo()
{
	int i , num , x = 0;
	
	// Asking accession number.
	printf("Enter accession number of the book you want to view details of: ");
	scanf("%d", &num); 
	
	for(i=0 ; i < count ; i++)
	{
		// if compare statement is true then print details.
		if(invent[i].accessionNo == num)
		{
			printf("Accession Number: %d\n",invent[i].accessionNo);
			printf("Title: ");
			puts(invent[i].title);
			printf("Author:");
			puts(invent[i].author);
			printf("Cost %d\n%s" , invent[i].cost , invent[i].flag == 1 ? "Issued\n" : "Unissued\n");
			x = 1;
		}
		if(x == 0)
		{
			printf("Book with number %d has not been entered yet.\n" , num);	
		}		
	}
	
	printf("\n\n");
}

void listAuthor()
{
	int i , cnt = 0;
	char n[50];
	
	// Asking author name
	printf("\nEnter the name of author you wish to view: ");
	getchar();
	
	fflush(stdin);
	
	gets(n);
	// where n is the name of the author
	// in order to accept string data type
	
	printf("Books of author are:");
	
	for(i = 0 ; i < count ; i++)
	{
		// Displaying details for the author name entered
	
		if(strcmp(n , invent[i].author) == 0)
		{
			cnt++;
			
			printf("\nBook %d\n" , i + 1);
			puts(invent[i].title);
			
			printf("Cost %d\n%s" , invent[i].cost , invent[i].flag == 1 ? "Issued\n" : "Unissued\n");
		}
	}
	
	if(cnt==0)
	{
		printf("No book of this author is in the library\n");
	}
	
	printf("\n\n");
}

void listTitle()
{
	int i , num , x = 0;
	
	
	// Asking accession 
	printf("Enter accession number of book you want to view the title of:");
	scanf("%d" , &num);
	
	for(i = 0 ; i < count ; i++)
	{
		if(invent[i].accessionNo == num)
		{
			printf("Title of Book No. %d\n",invent[i].accessionNo);
			puts(invent[i].title);
		
			x=1;
		}
		if(x == 0)
		{
			printf("Book with number %d has not been entered yet.\n" , num);
		}
	}
	
	printf("\n\n");
}

void countBook()
{
	printf("The total number of books in the library are: %d books" , count);// number of books
	
	printf("\n\n");
}

void listAcc()
{
	int i;
	
	for(i = 0 ; i < count ; i++)
	{
		printf("Details of Book No. %d\n" , invent[i].accessionNo);
		printf("Title: ");
		
		puts(invent[i].title);
		printf("Author: ");
		
		puts(invent[i].author);
		printf("Cost %d\n%s" , invent[i].cost , invent[i].flag == 1 ? "Issued\n" : "Unissued\n");
	}
	
	printf("\n\n");
}