#include <stdio.h>


// defining struct for date.
struct date
{
	int date;
	int month;
	int year;
};
	


int main (void){
	
	// declaring two variables for date.
	struct date date1, date2;
	
	// Taking input for first date.
	do{
	printf("Enter date 1 : ");
	scanf("%d", &date1.date);
    }while(date1.date >31 || date1.date < 0);
    
    do{
	printf("Enter month 1 : ");
	scanf("%d", &date1.month);
    }while(date1.month > 12 || date1.month < 0);
	
	do{
	printf("Enter year 1 : ");
	scanf("%d", &date1.year);
    }while(date1.year > 9999 || date1.year < 0);
    
	printf("\n\n");
	
	// Taking input for second date.
	do{
	printf("Enter date 2 : ");
	scanf("%d", &date2.date);
    }while(date2.date >31 || date2.date < 0);
    
    do{
	printf("Enter month 2 : ");
	scanf("%d", &date2.month);
    }while(date2.month > 12 || date2.month < 0);
	
	do{
	printf("Enter year 2 : ");
	scanf("%d", &date2.year);
    }while(date2.year > 9999 || date2.year < 0);
	printf("\n\n");
	
	// comparison statements
	if (date1.date == date2.date && date1.month == date2.month && date1.year == date2.year){
		printf("Equal");
	}
	else{
		printf("Unequal");
	}
	
	
}