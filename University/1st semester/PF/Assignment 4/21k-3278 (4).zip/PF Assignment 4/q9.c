#include <stdio.h>
#include <string.h>

 
int sort(float arr_marks[], char arr_name[][25], int arr_rollno[])
{
	int i, j, k, temp_rollno; 
	float temp_marks;
	char temp_name[25];
	
	printf("The unsorted data is:\n\n");
	for(i=0; i<7; i++)
	{
		printf("Roll number: %d\n", arr_rollno[i]);
		printf("Name: %s\n", arr_name[i]);
		printf("Marks: %f\n\n", arr_marks[i]);
	}

		
	for (i=0; i<7; i++)
	{
		for (j=i+1; j<7; j++)
		{
			if (arr_marks[j] < arr_marks[i])
			{
// Sorting marks.		
				temp_marks = arr_marks[i];
				arr_marks[i] = arr_marks[j];
				arr_marks[j] = temp_marks;

// Sorting roll_no.
				temp_rollno = arr_rollno[i];
				arr_rollno[i] = arr_rollno[j];
				arr_rollno[j] = temp_rollno;

// Sorting names.
				strcpy(temp_name, arr_name[i]);
				strcpy(arr_name[i], arr_name[j]);
				strcpy(arr_name[j], temp_name);
			}
		}
	}
	
	
	printf("The sorted data with respect to marks is:\n\n");
	for(i=0; i<7; i++)
	{
		printf("Roll number: %d\n", arr_rollno[i]);
		printf("Name: %s\n", arr_name[i]);
		printf("Marks: %f\n\n", arr_marks[i]);
	}	
	
	return 0;
}


int search_roll(int roll_no, int arr_rollno[], float arr_marks[], char arr_name[][25])
{
	int i;
	
	for(i=0; i<7; i++)
	{
		// print details if comparison statements are true.
		if (roll_no == arr_rollno[i])
		{
			printf("Roll number: %d\n", arr_rollno[i]);
			printf("Name: %s\n", arr_name[i]);
			printf("Mark: %f\n\n", arr_marks[i]); 
		}
	}
}


int search_name(char *name, int arr_rollno[], float arr_marks[], char arr_name[][25])
{
	int i; 
		
	for(i=0; i<7; i++)
	{
		// print details if comparison statements are true.
		if (strcmp(name, arr_name[i]) == 0)
		{
			printf("Name: %s\n", arr_name[i]);
			printf("Roll number: %d\n", arr_rollno[i]);
			printf("Marks: %f\n", arr_marks[i]); 
		}
	}
	
	return 0;
}

int main()
{
	int roll_no[7] = {1001, 1002, 1004, 1005, 1007, 1008, 1009};
	char std_names[7][25] = {"Salman", "Zubair", "Ahsan", "Farah", "Hassan", "Kamran", "Mariyum"};
	float std_marks[7] = {75.5, 80, 64, 78, 65, 54, 60};
	char name[25] ;
	int choice, roll_number;

	 	
	printf("Select the number of option you want to perform: ");
	printf("\n1. Sort the data\n2. Search and print the data based on roll number\n3. Search and print the data based on name\n");
	scanf("%d", &choice);
	
	switch(choice)
	{		
		case 1:
		{
			printf("Press enter Key to sort the data!\n");
			getchar();
			sort(std_marks, std_names, roll_no);
			break;				
		}		
		case 2:
		{
			printf("Enter the roll number of the student of whom you want to search for: ");
			scanf("%d", &roll_number);
			search_roll(roll_number, roll_no, std_marks, std_names);
			break;
		}	
		case 3:
		{
			printf("Enter the name of the student of whom you want to seach for: ");
			scanf("%s", &name);
			search_name(name, roll_no, std_marks, std_names);
			break;	
		}
	}
}

