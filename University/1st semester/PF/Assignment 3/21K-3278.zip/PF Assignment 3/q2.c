#include <stdio.h>

int main (void){
	
	int birth_year, student_id, MSD, LSD, third_prime = 5, ans = 1, lenght, i;
	
	// Taking input
	printf("Enter your birth year: (4 digit)");
	scanf("%d", &birth_year);
	
	printf("Enter your student id: ");
	scanf("%d", &student_id);
	
	// Validation since birth year cannot be greater than 4 digits 
	if (birth_year <= 9999 && birth_year > 999 && student_id >0)
	{
	
	// calculating msd and lsd
	MSD = birth_year/1000;
	
	LSD = student_id%10;
	
	for (i=1; i<=third_prime; i++){
		ans = ans * 2;
	}
	
	// calulating lenght
	lenght = MSD + LSD + ans; 
	
	// calculating series
	
	int num1 = 0;
	int num2 = 1;
	int nextnum = num1 + num2;
	
	printf("%d, %d, ", num1, num2);
	
	// printing finite series
	for (i=0; i<lenght-2; i++){
		
		printf("%d, ", nextnum);
		num1 = num2;
		num2 = nextnum;
		nextnum = num1 + num2; 
		
	}
    }
    else{
    	// error message
    	printf("Error....");
	}
	
	
}
