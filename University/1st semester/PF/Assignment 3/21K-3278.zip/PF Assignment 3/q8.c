#include <stdio.h>

int main (void){
	
	char situation, choice='Y';
	
while (choice == 'Y'){


    // Taking input
	printf("\nEnter n for normal situation\nEnter a for abnormal situation\nEnter situation: ");
	scanf(" %c", &situation);
	
	// compare with each each case and serve accordingly
	if (situation == 'n'){
		printf("Pattern A for normal situation\n");
	}
	else if (situation == 'a'){
		printf("Pattern B for abnormal position\n");
	}
	else{
		printf("Wrong entry...\n");
	}	
	
	printf("\n\n");
	
	// ask user if there are more inputs
	printf("Do you wish to continue? (Y/N)");
	scanf(" %c", &choice);

}
	
}