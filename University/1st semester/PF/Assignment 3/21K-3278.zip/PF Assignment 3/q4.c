#include <stdio.h>

int main (void){
	
	int SA_a, SA_b;
	int i, lcm=1, greatest, lowest; 
	
	// Taking input for data of both cars
	printf("Enter the time taken by car SA_a:\n");
	scanf("%d", &SA_a);
	
	printf("Enter the time taken by car SA_b:\n");
	scanf("%d", &SA_b);

if (SA_a > 0 && SA_b > 0){
	
    // storing the speed of the faster car in the variable greatest
	greatest = (SA_a > SA_b)? SA_a:SA_b;
		
	// calculating lcm since it will provide the time at which both
	// cars meet after one completes one more cycle than another.
	
while (1){

	if (greatest%SA_a==0 && greatest%SA_b==0){
		printf("Time at which the cars will meet is %d minutes", greatest);
		break;
	}
	else{
		greatest++;
	}
}
}
else{
	printf("Error...");
}
	return 0;

}
