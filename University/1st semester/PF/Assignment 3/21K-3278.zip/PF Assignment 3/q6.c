#include <stdio.h>

int main (void){
	
	int i, age;
	char area;
	
	// for 10 persons
	
	for(i=0; i<10; i++){
		
		printf("Enter your age: \n");
		scanf("%d", &age);
		
		// r for rural and u for urban
		printf("Enter your area (r/u)\n");
		scanf(" %c", &area);
		
		// serve according to input
		if (age>=18 && area == 'u'){
			printf("YOU ARE ELIGIBILE FOR VACCINE\n");
			
		}
		else if (age<=18 && area =='r'){
			printf("YOU ARE NOT ELIGIBLE FOR VACCINE\n");
		}
		
	}
	
}