#include<stdio.h>
int main()
{
	int i, j, num;
	char letter;
	
	printf("\n Enter the number of letters you want to output(max. 26): ");
	scanf("%d", &num);
	
	if (num > 26){
		
		// to avoid printing garbage value
		printf("Error...");
	}
	else{
	
	// this for loop is used for number of line	
	for(i=1;i<=num;i++)
	{
		printf("\n");
		
		// this for loop is used for number of alphabets in a row
		for(j=1;j<=i;j++)
		{
			// used 64 since ASCII value of a is 65 and the counter j starts from 1
			letter = 64 + j;
			printf("%c", letter);
		}
	}
    }
}
