#include <stdio.h>

int main (void){
	
	int rem1, rem2, rem3, z=1, j=1, k=1, decimal1, decimal2, decimal3, octal1=0, octal2=0, octal3=0, x; 
	char choice='Y';
	
	while (choice == 'Y'){
		
		
	// Taking decimal date input
	printf("Enter date :");
	scanf("%d", &decimal1);
	
	if (decimal1 < 99 && decimal1 > 0){
	// taking remainder with 8 on each iteration and then reducing the decimal.
	while(decimal1>0){
		
		rem1 = decimal1%8;
		decimal1=decimal1/8;
		octal1+=rem1*z ;
		z *= 10;
	} 
	
    }
    else{
    	break;
	}
	
	
	
	// Taking decimal month input
	printf("Enter month :");
	scanf("%d", &decimal2);
	
	if (decimal2 > 0 && decimal2 <= 12){
	// taking remainder with 8 on each iteration and then reducing the decimal.
	while(decimal2>0){
		
		rem2 = decimal2%8;
		decimal2=decimal2/8;
		octal2+=rem2*j ;
		j *= 10;
	}
	}
	else{
		break;
	}
	
	
	
	
	
	// Taking decimal year input
	printf("Enter year :");
	scanf("%d", &decimal3);
	
	// taking remainder with 8 on each iteration and then reducing the decimal.
	if (decimal3 > 0 && decimal3 <= 9999)
	while(decimal3>0){
		
		rem2 = decimal3%8;
		decimal3=decimal3/8;
		octal3+=rem2*k ;
		k *= 10;

	} 
	else{
		break;
	}
	
	printf("Octal for date = %d\n", octal1);
	
	printf("Octal for month = %d\n", octal2);
	
	printf("Octal for year = %d\n", octal3);
	
	
	printf("Do you wish to continue? (Y/N)");
	scanf(" %c", & choice);
	
	z=1, k=1, j=1, octal1=0, octal2=0, octal3=0; // initialising counters for the next iteration.
	
}
	
return 0;	
}


	
	
	




