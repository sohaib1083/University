#include <stdio.h>

int main (void){
	
	float num;
	int neg=0, pos=0, zeros=0, majority_count;
	char choice = 'Y';

		
while (choice=='Y'){
	
	// taking input
	printf("Enter a real number\b");
	scanf("%f", &num);
	
	
	// According to nature of the number, increment its counter
	if (num == 0){
		zeros++;
	}
	else if (num > 0){
		pos++;
	}
	else if (num < 0){
		neg++;
	}
	
	printf("Do you wish to continue? (Y/N) \n");
	scanf(" %c", &choice);
	
}	
    // output the value of all counters
	printf("%d negatives were entered by the user\n", neg);
    printf("%d positives were entered by the user\n", pos);
	printf("%d zeros were entered by the user\n", zeros);
	
	// output the value of the highest counter (majority count)
	if (neg > pos && neg > zeros){
		majority_count = neg;
		printf("The Max counter is : %d\n", majority_count);
	}
	else if (pos > neg && pos > zeros){
		majority_count = pos;
		printf("The max counter is : %d\n", majority_count);
    }
    else if (zeros > pos && zeros > neg){
		majority_count = zeros;
		printf("The max counter is : %d\n", majority_count);
    }
    else if (neg == pos && pos != zeros){
		printf("The max counters are : %d, %d\n", neg, pos);
	}
    else if (zeros == neg && zeros != pos){
    	printf("The max counters are : %d, %d\n", zeros, neg);
	}
	else if (pos == zeros && pos != neg){
		printf("The max counters are : %d, %d\n", pos, zeros);
	}
    
    
    
}