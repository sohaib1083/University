#include <stdio.h>
#include <math.h>

int main(){
	
	int i, j, k, age, check, num;
	
    // Taking input	
	printf("Enter your age: ");
	scanf("%d", &age);
	
	if (age>0)
	{
        // first for loop for checking numbers to be a part of triplet	
		for (i=1; i<age; i++)
		{
            // second for loop for checking numbers part of triplet with i+1
			for (j=i+1; j<age; j++)
			{
                // Pass the value of a^2 + b^2 in num for the formula a^2 + b^2 = c^2 			
				num = pow(i,2) + pow(j,2);

		        // to check pythagorian theorem (a^2 + b^2 = c^2) : comparing num with the square of counter k
				for (k=i+2; k<age; k++)
				{
					if (num == (k*k))
					{
						printf("%d, %d, %d\n", i, j, k);
					}
				} 
			}
		}

	}
	else
	{
		printf("Error....");
	}
	return 0;
}
