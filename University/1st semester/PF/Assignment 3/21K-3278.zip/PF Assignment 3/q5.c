#include <stdio.h>
#include <math.h>

int main(){
	
	int i, num;
	float N, distance, x, y;
	char alpha = 'A';

    // Taking input	
	printf("Enter the 7 digit of your mobile number without prefix: ");
	scanf("%d", &num);

    // check if its within 7 digits
	if (num>=0 && num<=9999999)
	{
        // This calculates MSD	
		num /= 10000000;
		
	    // Check if MSD is within 0-9
		if (num > 0 && num <=9)
		{
			N = (pow(2, num)) * 0.0625;
            // N is converted into integer data type.			
			(int)N;
			
		    // calculate distance for N times
			for (i=1; i<=N; i++)
			{
				printf("Enter co-ordinates for the point %c(x,y): ", alpha);
				scanf("%f %f", &x, &y);
				distance = sqrt((pow(x-1, 2)) + (pow(y-3, 2)));
				printf("The distance between R and %c is %g.\n", alpha, distance);
				alpha++;
			}
		}
        // This calculates distance if the value of MSD is 0 and repeat the same process
		else
		{
			N = ((pow(2, num)) * 4)+ 3;
		
			(int)N;
				
			for (i=1; i<=N; i++)
			{
				printf("Enter the co-ordinates for point %c (x y): ", alpha);
				scanf("%f %f", &x, &y);
				distance = sqrt((pow(x-1, 2)) + (pow(y-3, 2)));
				printf("The distance between R and %c is %g.\n", alpha, distance);
				alpha++;
			}		
		}
	}
	
	else
	{
		printf("Error....");
	}
	
	return 0;
}
