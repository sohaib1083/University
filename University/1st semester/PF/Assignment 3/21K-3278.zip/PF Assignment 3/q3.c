#include<stdio.h>
#include<math.h>
int main(){
	float x, p, fac=1, a, sum=1;
	int i;
	// Taking input for x
	printf("Please enter the value for x\n");
	scanf("%f", &x);
	
	int n=14;//largest factor of 42 and 98
	
	for(i=1 ; i<=n ; i++)
	{
		p=pow(x,i);
		fac=fac*i;
		a=p/fac;
		sum=sum+a;
	}
	printf("sum = %.2f\n", sum);
}
