#include<stdio.h>

int main (void)
{
	int x, x1, x2, x4, x5;
	
	// Take input of a five digit positive integer.
	
	printf("Enter a five digit positive integer: \n");
	scanf("%d", &x);
	
/*
If user input a negative number or more than 5 digits then print error.

Compare the first digit with Last digit and second digit with fourth digit,
if both of the comparisons are true then print its a palindrome else print it
is not a palindrome

*/
	
	if (x < 0 || x/100000 % 10 > 0)
	{
		printf("Error invalid input! Please try again \n");
	}
	else
	{
		x1 = x/10000;
		x2 = x/1000 % 10;
		x4 = x/10 % 10;
		x5 = x % 10;
		
		if (x1 == x5 && x2 == x4)
		{
			printf("It is a palindrome!\n");
		}
		else
		{
			printf("It is not a palendrome.\n");
		}
	}
	
}
