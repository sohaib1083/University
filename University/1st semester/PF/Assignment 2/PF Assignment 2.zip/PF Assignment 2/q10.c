#include <stdio.h>

int main (void)
{
	int x, x1, x2, x3, x4, temp1, temp2;
	
	// Input a four digit integer and store in x. If it has more or less than
	// four digits or is negative then output error. 
	
	
	printf("Enter any four digit integer:\n ");
	scanf("%d", &x);
	
	if (x > 9999 || x < 1000)
	{
		printf("Invalid input. Try again!\n ");
	}
	else
	{
		// extract each individual digit and add 5 to it.
		
		x1 = x/1000 + 5;
		x2 = x/100 % 10 + 5;
		x3 = x/10 % 10 + 5;
		x4 = x % 10 + 5;
		
		// store remainder when dividing the new value by 8.
		
		x1 = x1 % 8;
		x2 = x2 % 8;
		x3 = x3 % 8;
		x4 = x4 % 8;
		
		// swaping the first and second, third and the fourth.
		
		temp1 = x2;
		x2 = x1;
		x1 = temp1;
		
		temp2 = x4;
		x4 = x3;
		x3 = temp2;
		
		// Taking a copy.
		
		int y1 = x1;
		int y2 = x2;
		int y3 = x3;
		int y4 = x4;
		
		// output the encrypted integer.
		
		printf("The encrypted integer is %d%d%d%d\n ", x1, x2, x3, x4);
		
		// reversing the encryption method //
		
		
		// ordering back the digits to original position.
		
		temp1 = x1;
		x1 = x2;
		x2 = temp1;
		
		temp2 = x3;
		x3 = x4;
		x4 = temp2;
		
		x1 = (x1 + 8) - 5;
		x2 = (x2 + 8) - 5;
		x3 = (x3 + 8) - 5;
		x4 = (x4 + 8) - 5;
		
		printf("The decrypted integer is: %d%d%d%d\n ", x1, x2, x3, x4);
		
		if (x1 == y1 && x2 == y2 && x3 == y3 && x4 == y4)
		{
			printf("The data before encryption and after decryption is the same. Congrats!\n ");
		}
		else
		{
			printf("The data before encryption and after decryption is not the same. Troubleshoot your code.!\n ");
		}
	}
	
	
	
	
}
