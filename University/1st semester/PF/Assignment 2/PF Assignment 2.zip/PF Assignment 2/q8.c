#include <stdio.h>

int main (void)
{
	int nums;
	char c1, c2;
	int count1 = 0;
	int count2 = 0;
	
	// Take input of the choice of number of characters in the roman number.
		
	printf("How many characters are there in your roman number?");
	scanf("%d", &nums);
	
/*

If the choice is 2 then input both as chars, using switch statements compare with each character. Whenever the comparison is true, store the decimal value of
that char to count1 ad exit the loop. Do the same with the second character and store its value to count2. If count2 is greater then print count2 - count1 else 
print count1 + count2.

If the choice is 1 then input the single char, compare using switch statements and exit loop as soon comparison is true after storing the decimal value to count1.
Finally print count1.

If the choice is other than 1 or 2 then print error.

*/
	
	switch(nums)
	{
	    case 2:
	    {
				
	    printf("Enter the first character:");
		scanf(" %c", &c1);
		
		printf("Enter the second character:");
		scanf(" %c", &c2);
	 
		
	        switch(c1)
		    {
			case 'I':
			{
				count1 = 1;
				break;
			}	
			case 'V':
			{
				count1 = 5;
				break;
			}
			case 'X':
			{
				count1 = 10;
				break;
			}
			case 'L':
			{
				count1 = 50;
				break;
			}
			case 'C':
			{
				count1 = 100;
				break;
			}
			case 'D':
			{
				count1 = 500;
				break;
			}
			case 'M':
			{
				count1 = 1000;
				break;
			}
			default:
				printf("Invalid operation\n");
				break;
	        }
			
			
		    switch(c2)
		    {
			case 'I':
			{
				count2 = 1;
				break;
			}	
			case 'V':
			{
				count2 = 5;
				break;
			}
			case 'X':
			{
				count2 = 10;
				break;
			}
			case 'L':
			{
				count2 = 50;
				break;
			}
			case 'C':
			{
				count2 = 100;
				break;
			}
			case 'D':
			{
				count2 = 500;
				break;
			}
			case 'M':
			{
				count2 = 1000;
				break;
			}
			default:
				printf("Invalid operation\n");
				break;
	        }
		
		    if (count1 < count2)
		    {
		    count2 = count2 - count1;
		    }
		    else
		    {
			count2 = count2 + count1;
		    }
		
		    printf("The decimal equivalent is %d ", count2);
    
	    }
        break;
        
    
        case 1:
		{
				
	    printf("Enter the first character \n");
	    scanf(" %c", &c1);
		
	    switch(c1)
		{
			case 'I':
			{
				count1 = 1;
				break;
			}	
			case 'V':
			{
				count1 = 5;
				break;
			}
			case 'X':
			{
				count1 = 10;
				break;
			}
			case 'L':
			{
				count1 = 50;
				break;
			}
			case 'C':
			{
				count1 = 100;
				break;
			}
			case 'D':
			{
				count1 = 500;
				break;
			}
			case 'M':
			{
				count1 = 1000;
				break;
			}
			default:
				printf("Invalid operation\n");
				break;	
		}   
		
		printf("decimal equivalent is %d", count1);
		break;
	    }
        default:
		printf("Invalid input.");
		  
    }
return 0;	
	
}
