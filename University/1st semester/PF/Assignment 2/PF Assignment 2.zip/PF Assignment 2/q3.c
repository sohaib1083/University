#include<stdio.h>

int main (void)
{
	// input all 4 sides and 4 angles 
	float s1, s2, s3, s4, a1, a2, a3, a4;
	
	printf("Enter all 4 sides of the shape\n");
	scanf("%f%f%f%f", &s1, &s2, &s3, &s4);
	
	
	printf("Enter all 4 angles of the shape\n");
	scanf("%f%f%f%f", &a1, &a2, &a3, &a4);
	
/*

if all angles are 90 degrees and all sides are equal then display its a square.
if all angles are 90 and there are pairs of equal sides then display its a rectangle.
if there are two pairs of equal angles and all equal sides then display its a rhombus.
if there are two pairs of same equal angles and two pairs of equal sides then display its a parallelogram.
if there is one pairs of same equal angles and one pairs of equal sides then display its a kite.
else if the sum of all angles is 360 then display its a trapezoid.
   
*/
	
	if (a1 == 90.0 && a2 == 90.0 && a3 == 90.0 && a4 == 90.0)
	{
	     if (s1 == s2 && s1 == s3 && s1 == s4 && s2 == s3 && s2 == s4 && s3 == s4)
	     {
	       printf("square\n");
	     }
          else
	     {
           printf("rectangle\n");	
         }
    }
    else if ((a1 == a2 && a3 == a4) || (a1 == a3 && a2 == a4) || (a1 == a4 && a2 == a3))
    {
         if (s1 == s2 && s1 == s3 && s1 == s4 && s2 == s3 && s2 == s4 && s3 == s4)
	     {
	       printf("rhombus\n");
	     }
         else if (a1 + a2 == 180.0 && a3 + a4 == 180.0 || a1 + a3 == 180.0 && a2 + a4 == 180.0 || a1 + a4 == 180.0 && a2 + a3 == 180.0)
	     {
           printf("parallelogram\n");	
         }	
    }
    
    else if (s1 == s2 || s1 == s3 || s1 == s4 || s2 == s3 || s2 == s4 || s3 == s4)
         {
         	printf("Kite\n");
		 }
    else if (a1 + a2 + a3 + a4 == 360)
	{
		printf("trapezoid\n");
	}
		 
}
