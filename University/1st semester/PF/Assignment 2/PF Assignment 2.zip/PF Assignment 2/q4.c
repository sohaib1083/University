#include <stdio.h>

int main (void)
{
	
	// Takes the input of a positive four digit or less from the user And asks for the
	// last number in the roll number and store in y
	int x, x1, x2, x3, x4, y;
	int count;
	
	printf("Enter a four digit positive integer:");
	scanf("%d", &x);
	
	printf("Enter the last digit of your roll no.: \n");
	scanf("%d", &y);
	
/*
If user enters a number with more than 4 digits or a negative number then print error.

Compare this y with each digit, each time when the comparison is true then
increment count.

Finally print count as the number of time y occured.

*/

	
	if ( x/10000 > 0 || x < 0 || x/1000 == 0)
	{
		printf("invalid integer");
	}
	
	else
    {
    	
    x1 = x/1000;
    x2 = x/100 % 10;
    x3 = x/10 % 10;
    x4 = x % 10;
     	
    if (y == x1)
	{
		count++;
	} 
	if (y == x2)
	{
		count++;
	}
	if (y == x3)
	{
		count++;
	}
	if (y == x4)
	{
		count++;
	}
     printf("%d occured %d times", y, count);	
	}
	
	
	
}
