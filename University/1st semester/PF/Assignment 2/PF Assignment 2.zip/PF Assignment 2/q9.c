#include <stdio.h>

int main (void)
{
	int x, count, decimal;
	
	// Take last two digits of roll number as input (x).If the user enters more
    // than two digits or a negative integer then print an error.

	
	printf("Enter the last two digits of your roll number: \n");
	scanf("%d", &x);
	
	if ( x > 99 || x < 10)
	{
		printf("Invalid input. Please try again later!");
	}
	
/*

Compare x with the multiples of 2, if x is greater then 1 is added
to that place in the count variable and the multiple is subtracted from x till 
x gets to 0.

Output the count variable as the binary equivalent.

*/
	
	else
	{
	
	int y = x;
	
	if (x >= 64)
	{
		count = count + 1000000;
		x = x - 64;
	}
	
	if (x >= 32) 
	{
		count = count + 100000;
		x = x - 32;
	}
	if (x >= 16)
	{
		count = count + 10000;
		x = x - 16;
	}
	if (x >= 8)
	{
		count = count + 1000;
		x = x - 8;
	}
	if (x >= 4)
	{
		count = count + 100;
		x = x - 4;
	}
	if (x >= 2)
	{
		count = count + 10;
		x = x -2;
	}
	if (x >= 1)
	{
		count = count + 1;
		x = x - 1;
	}
	
	
/* calculating decimal equivalent

Then compare each digit on binary with 1, whenever the comparison is true, 
add the value of multiple of 2 in the variable decimal until the numbers end.
   
Output the decimal variable as the decimal equivalent.

*/
	
	if (count/1000000 % 10 == 1)
	{
		decimal = decimal + 64;
	}
	if (count/100000 % 10 == 1)
	{
		decimal = decimal + 32;
	}
	if (count/10000 % 10 == 1)
	{
		decimal = decimal + 16;
	}
	if (count/1000 % 10 == 1)
	{
		decimal = decimal + 8;
	}
	if (count/100 % 10 == 1)
	{
		decimal = decimal + 4;
	}
	if (count/10 % 10 == 1)
	{
		decimal = decimal + 2;
	}
	if (count % 10 == 1)
	{
		decimal = decimal + 1;
	}
	
	printf("The binary equivalent of %d is %d \n", y, count);
	printf("The decimal equivalent of %d is %d \n", count, (decimal - 1));
	printf("Hurrah!! your program is correct.");
}
}

