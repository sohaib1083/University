#include <stdio.h>

int main (void)
{
	float x1, x2, x3, x4, y1, y2, y3, y4;
	float m1, m2, m3;
	
	// Input x and y value for all 4 coordinates.
	
	printf("Enter the coordinates of first point (x1,y1): \n");
	scanf("%f%f", &x1, &y1);
	
	printf("Enter the coordinates of second point (x2,y2): \n");
	scanf("%f%f", &x2, &y2);
	
	printf("Enter the coordinates of third point (x3,y3): \n");
	scanf("%f%f", &x3, &y3);
	
	printf("Enter the coordinates of fourth point (x4,y4): \n");
	scanf("%f%f", &x4, &y4);
	
	// Calculate gradient by formula between: point 1 and 2, point 2 and 3, point 3 and 4.
	
	m1 = (y2 - y1)/(x2 - x1);
	m2 = (y3 - y2)/(x3 - x2);
	m3 = (y4 - y3)/(x4 - x3);
	
/*

Compare all of the gradients, If all of the are equal then print that the points
fall on the same line else print it donot fall on the same point. 

*/
	
	if (m1 == m2 && m2 == m3)
	{
		printf("The given points fall on a straight line! \n");
	}
	else
	{
		printf("The given points donot fall on a straight line \n");
	}
}
