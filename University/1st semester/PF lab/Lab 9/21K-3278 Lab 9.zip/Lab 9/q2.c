#include <stdio.h>
#include <string.h>


int main (void)
{
	
	char course[20], freq[255], result;
	int i, ascii, max =0, j;
	
	// Taking values from user
	printf("Enter course name: ");
	gets(course);
	
	
	// intiallising frequency array
	for (i=0; i<255; i++)
	{
		freq[i] = 0;
	}
	
	// scanning the course name
	for (i=0; i<strlen(course); i++)
	{
	
		ascii = (int)course[i];
		freq[ascii] += 1;
		
	}
	
	// initialising max
	max = 0;
	
	// calculating max
	for (j=92; j<254; j++)
	{
		
		if (freq[j] > max){
			max =freq[j];
			result = j;
		}
		
	}
	
	//giving output
	printf("This alphabet %c is which repeated %d times", result, max);

	
}