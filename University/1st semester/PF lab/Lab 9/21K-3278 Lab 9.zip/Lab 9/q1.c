#include <stdio.h>
#include <string.h>

int main (void)
{

    char n1[50], n2[50];
    int size1, i;
    
	
	// Taking input
	printf("Enter first name:");
	gets(n1);
	
	printf("Enter last name:");
	gets(n2);
	
	printf("After concatenation is %s", strcat(n1, n2));
	
	printf("\n");
	
	size1 = strlen(n1);
	
	printf("The string in reverse order is: ");
	
	for(i=size1; i>=0; i--)
	{
		
		printf("%c", n1[i]);
		
	
	}
	
	
	
	
	
}