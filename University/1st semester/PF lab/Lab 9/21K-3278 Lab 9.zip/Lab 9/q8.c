#include<stdio.h>

int main(){
	
	int a[101] = {0};
	int n, i;
	
	printf("Enter size of array: ");
	scanf("%d", &n);
	
	int arr[n];
	
	printf("Enter elements in array: ");
	
	for(i = 0; i < n; i++){
		scanf("%d", &arr[i]);
		a[arr[i]]++;
	}
	
	printf("Frequency of all elements of array:\n");
	
	for(i= 0; i <101; i++){
		if(a[i] > 0){
			printf("%d occurs %d times\n", i, a[i]);
		}
	}
	
}
