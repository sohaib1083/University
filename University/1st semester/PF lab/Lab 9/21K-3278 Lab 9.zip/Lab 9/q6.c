#include <stdio.h>

int check_prime (int roll)
{
	roll = roll % 10;
	int i, flag=0;
	for (i=2; i<roll; i++)
	{
		if (roll%i == 0){
			flag = 1;
		}
	}
	if (roll == 1 || roll == 2){
		flag = 0;
	}
	
	if (flag == 0){
		return 1;
	}
	else{
		return 0;
	}
}


int main (void){
	
	int roll_num, value;
	
	printf("Enter 4 digit roll no.: ");
	scanf("%d", &roll_num);
	
	value = check_prime(roll_num);
	
	if (value == 1){
		printf("The number is prime...");
	}
	else{
		printf("The number is not a prime...");
	}
}