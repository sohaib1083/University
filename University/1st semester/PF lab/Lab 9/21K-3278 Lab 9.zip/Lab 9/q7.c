#include<stdio.h>

int main(){
	float length[8] = {150.6, 354, 172.23, 73.33, 415.15, 415.15, 415.15, 415.15};
	float width[8] = {126.9, 451.51, 75.65, 707.17, 116.17, 116.17, 116.17, 116.17};
	float area[8];
	
	int i;
	printf("Areas of the land are: ");
	for(i = 0; i < 8; i++){
		area[i] = length[i] * width[i];
		printf("\n%d : %.2f,", i+1, area[i]);
	}
	float max = area[0];
	int m;
	
	for(i = 1; i < 8; i++){
		if(area[i] > max){
			max = area[i];
			m = i;
		}
	}
	
	printf("\n\nNumber %d land piece is largest in area: %.2f", m+1, max);
	
	return 0;
}
