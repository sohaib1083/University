#include <stdio.h>
#include <math.h>

float getData(void);
float volumeCal(int h, int a);

int main (void){
	
	printf("The volume of pyramid is : %.2f", getData());
	return 0;
}

float getData(void)
{
	float vol;
	int h, a;
	printf("h = height \na = base\n");
	
	printf("Enter h :");
	scanf("%d", &h);
	
	printf("Enter a :");
	scanf("%d", &a);
	
	vol = volumeCal(h, a);
	
	return vol;
		

}

float volumeCal(int h, int a)
{
	
	float volume = (pow(a,2) * h * 1/3.0);
	
	return volume;
	
	
}