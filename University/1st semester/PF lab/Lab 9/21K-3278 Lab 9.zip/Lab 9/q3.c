#include <stdio.h>
#include <string.h>

int position (int);//prototype

int test_score;

int main (void)
{
	
	printf("Enter test score: ");
	scanf("%d", &test_score);
	
	if (test_score >=50){
	  position(test_score);
    }
    else{
	printf("Not applicable....");
}
	return 0;

}

int position (int n)
{
	
	while (1)
	{
	
	int exp;
	
		printf("Enter experience: ");
		scanf("%d", &exp);
	
	if (n >= 50){
		printf("1. Trainee Engineer\n");
	}  
	if (n >= 60 && exp >= 1){
		printf("2. Assistant developer\n");
		}
	if (n >= 70 && exp >=2){
		printf("3. Associate developer\n");
		}
		break;
	}
    }
