#include <stdio.h>

int main (void){
	
	int i, j;
	int a[5][9], sum = 0;
	
	// initialising seventh column with roll no.
	for(i=0; i<5; i++)
	{
		a[i][6] = 100;
	}
	
	
	for(i=0; i<5; i++)
	{
		
		for (j=0; j<=5; j++)
		{
			if (j == 0){
				printf("Enter roll no. :");
				scanf("%d", &a[i][j]);
			}
			printf("Enter C%d marks for std-id %d :", j + 1, i+1);
			scanf("%d", &a[i][j]);
			sum = sum + a[i][j];
		}
		
		
		// marks obtained 2
		a[i][j+1] = sum;
		
		// percentage
		a[i][j+2] = ((float)sum/a[i][j])*100;
		
		sum=0;
	}
	
	printf("\n\n");
	
	// printing the table 
	for (i=0; i<5; i++){
		
		for (j=0; j<9; j++){
			printf("%d  ", a[i][j]);
		}
		printf("\n\n");
	}
	
}