#include <stdio.h>

int main (void){
	
	int i, j;
	
	for (i=3; i<10; i+=2){
		
		for (j=3; j<10; j+=2){
			printf("%d * %d = %d\n", i, j, i*j);
		}
		
	}

	
}
	
