#include <stdio.h>

int main (void){
	
	int class[10];
	int i, j, Temp;
	int max, min;
	
	for (i=0; i<10; i++){
		
		printf("Enter marks for student %d :\n", i+1);
		scanf("%d", &Temp);
		
		if (Temp > 10){
			
			printf("Wrong entry\n");
			
			while (Temp > 10){
				printf("Enter marks for student %d :\n", i+1);
		        scanf("%d", &Temp);
			}
		}
		else{
			class[i] = Temp;
		}
	}
	
	max = class[0];
	min = class[0];
	
	printf("The marks you entered: \n");
	
	for (j=0; j<10; j++){
		
		printf("%d\n", class[j]);
		
		if (class[j] > max){
			max = class[j];
		}
		if (class[j] < min){
			min = class[j];
		}
	}
	
	printf("Maximum = %d\n", max);
	printf("Minimum = %d\n", min);
	
	return 0;
}
