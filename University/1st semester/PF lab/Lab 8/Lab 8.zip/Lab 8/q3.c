#include <stdio.h>

int main (void){
	
	float a[6]; 
	int i, j;
	
	for (i=0; i<=5; i++)
	{
		printf("Enter element number %d \n", i+1);
		scanf("%f", &a[i]);
			
	}
	 
	printf("Array in reverse order is :\n");
	
	for (j=5; j>=0; j--)
	{
		printf("%f, ", a[j]);
	}
	
	
	return 0;
}
