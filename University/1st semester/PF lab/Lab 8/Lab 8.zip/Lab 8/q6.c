#include <stdio.h>

int main (void){
	
	int class1[5], class2[5];
	int i, j, k, Temp, count=0;
	
	// array 1
	for (i=0; i<5; i++){
		
		printf("Enter marks for student %d :\n", i+1);
		scanf("%d", &Temp);
		
		if (Temp > 10){
			
			printf("Wrong entry\n");
			
			while (Temp > 10){
				printf("Enter marks for student %d :\n", i+1);
		        scanf("%d", &Temp);
			}
		}
		else{
			class1[i] = Temp;
		}
	}
	
	printf("Enter marks for second class\n");
	
	// array 2
	for (k=0; k<5; k++){
		
		printf("Enter marks for student %d :\n", k+1);
		scanf("%d", &Temp);
		
		if (Temp > 10){
			
			printf("Wrong entry\n");
			
			while (Temp > 10){
				printf("Enter marks for student %d :\n", i+1);
		        scanf("%d", &Temp);
			}
		}
		else{
			class2[k] = Temp;
			
			for (j=0; j<5; j++){
				if (class1[j] == class2[k]){
				count++;
			}
			}
		}
	}
	
	printf("There are total %d common marks in both classes", count);
	
	return 0;

}
