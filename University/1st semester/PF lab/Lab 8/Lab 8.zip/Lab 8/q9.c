#include <stdio.h>

int main (void){
	
	int size, i, element, element_posn, j, k;
	
	printf("Enter the size of array: ");
	scanf("%d", &size);
	
	int a[size];
	
	for (i=0; i<size; i++){
		
		printf("Enter elements in array: ");
		scanf("%d", &a[i]);
			
	}
		
	printf("Enter the element position to delete: ");
	scanf("%d", &element_posn);
	
	k=element_posn;
	
	while (k<size){
		a[k-1]=a[k];
		k++;
	}
	
	for(j=0; j<size-1; j++){
		printf("%d ", a[j]);
	}
}
