#include <stdio.h>

int main (void){
	
	float a[4]; 
	int i;
	float sum;
	
	for (i=0; i<3; i++){
		
		scanf("%f", &a[i]);
		sum += a[i];
	}
	
	printf("The sum is %.2f\n", sum);
	printf("The average is %.2f\n", sum/i);
	
	return 0;
}
