#include <stdio.h>

int main (void){
	
	int n, i, j, k=0;
	
	printf("Enter the value of n: ");
	scanf("%d", &n);
	
	printf("\n");
	
	for (i=1; i<=n*2; i++)
	{
 
		if (i<=n){
			k++;
		}
		else if (i>=n+2){
			k--;
		}
		
		for (j=1; j<=n*2; j++)
		{
			if (j<=n+1-k || j>=n+k){
				printf("*");
			}
			else{
				printf(" ");
			}
		}
		printf("\n");
	}
	return 0;
}