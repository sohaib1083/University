#include <stdio.h>

int main (void){
	
	int size, i, element, element_posn, j, k;
	
	printf("Enter the size of array: ");
	scanf("%d", &size);
	
	int a[size+1];
	
	for (i=0; i<size; i++){
		
		printf("Enter elements in array: ");
		scanf("%d", &a[i]);
		
	}
	
	printf("Enter the element to insert: ");
	scanf("%d", &element);
	
	printf("Enter the element position: ");
	scanf("%d", &element_posn);
	
	k=size;
	
	while (k>=element_posn){
		a[k]=a[k-1];
		k--;
	}
	a[element_posn-1]=element;
	
	printf("Array elements after insertion: ");
	
	for(j=0; j<size+1; j++){
		printf("%d ", a[j]);
	}
}
