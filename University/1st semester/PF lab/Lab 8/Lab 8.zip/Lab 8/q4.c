#include <stdio.h>

int main (void){
	
	int i, j, count=0, size1, size2;
    
	printf("Enter the number of elements in the first array: \n");
	scanf("%d", &size1);
	
	printf("Enter the number of elements in the second array: \n");
	scanf("%d", &size2);
	
    int a[size1], b[size2];
	
	for (i=0; i<size1; i++)
	{
		printf("Enter the element number %d :", i+1);
		scanf("%d", &a[i]);
		
	}
	
	printf("Enter the elements of second array\n");
	
	for (j=0; j<size2; j++)
	{
		printf("Enter the element number %d :", j+1);
		scanf("%d", &b[j]);
		
		if (b[j] == a[j]){
			count++;
		}
		
	}
	
	if (count == size1 && count == size2){
		printf("Array is symmetric");
	} 
	else{
		printf("Not symmetric");
	}
	
	
	return 0;
}
