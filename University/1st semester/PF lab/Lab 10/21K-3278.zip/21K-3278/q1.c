#include <stdio.h>
#include <math.h>

int rev(int y);

int palindrome(int y);

int main()
{
    int y;
    
    printf("number: ");
    scanf("%d", &y);
    
    if(palindrome(y) == 1)
    {
        printf("%d is a palindrome number.\n", y);
    }
    else
    {
        printf("%d is NOT a palindrome number.\n", y);
    }
    
    return 0;
}

int palindrome(int y)
{
    if(y == rev(y))
    {
        return 1;
    }
    
    return 0;
}

int rev(int y)
{
    int digit = (int)log10(y);
    
    if(y == 0)
    {
    	return 0;	
	}

    return ((y % 10 * pow(10 , digit)) + rev(y / 10));
}
