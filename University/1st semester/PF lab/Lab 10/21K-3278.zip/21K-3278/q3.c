#include <stdio.h>

struct Phone
{
	int area_code;
	int exchange;
	int num;
} my_phone, your_phone; // global


int GetInfo (void); // prototype


int main (void){
	
	// initialisation - hard code
	my_phone.area_code = 212;
	my_phone.exchange = 767;
	my_phone.num = 8900;
	
	GetInfo();
	
	printf("My phone number is (%d) %d-%d\n",my_phone.area_code, my_phone.exchange, my_phone.num);
	printf("Your phone number is (%d) %d-%d\n",your_phone.area_code, your_phone.exchange, your_phone.num);
	
}


int GetInfo ()
{
	printf("Enter area code: ");
	scanf("%d", &your_phone.area_code);
	
	printf("Enter exchange: ");
	scanf("%d", &your_phone.exchange);
	
	printf("Enter number: ");
	scanf("%d", &your_phone.num);
	
	
}
