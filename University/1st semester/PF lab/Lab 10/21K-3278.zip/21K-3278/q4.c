#include <stdio.h>

struct student
{
	int stu_id;
	int stu_age;
	char stu_name[50];
	int street_num; 
	char state[50];
	char city[50];
    char country[50];
		
};

int main (void){
	
	int N, i;
	         
	struct student stud[100]; // local
	
	printf("Enter N number of users: ");
	scanf("%d", &N);
	
	for (i=1; i <= N; i++)
	{
		
		printf("Enter student #%d id :", i);
		scanf("%d", &stud[i].stu_id);
		
		printf("Enter student #%d age :", i);
		scanf("%d", &stud[i].stu_age);
		
		printf("Enter student #%d name :", i);
		scanf("%s", &stud[i].stu_name);
		
		printf("Enter student #%d street number :", i);
		scanf("%d", &stud[i].street_num);
		
		printf("Enter student #%d state :", i);
		scanf("%s",&stud[i].state);
		
		printf("Enter student #%d city :", i);
		scanf("%s", &stud[i].city);
		
		printf("\n");
	}
	printf("Values stored.\nDONE");
	
	return 0;
}
