#include <stdio.h>

struct comp{
	int img;
	int real;
};

// prototypes
struct comp reading();
writing(struct comp);
struct comp addition(struct comp c1, struct comp c2);
struct comp multiplication(struct comp c1, struct comp c2);

int main (void){
struct comp c1, c2, add, mult;


	c1 = reading();
	c2 = reading();

    writing(c1);
    writing(c2);

    add = addition(c1, c2);
    
    printf("\n");
    
    printf("The sum of both complex number is %d + (%di)", add.real, add.img);

    mult = multiplication (c1, c2);	
    
    printf("\n");
	
	printf("The multiplication product of both complex number is %d + (%di)", mult.real, mult.img);    
	
}

struct comp reading()
{
	struct comp c;
	
	printf("Enter Real part: ");
	scanf("%d", &c.real);
	
	printf("\n");
	
	printf("Enter Imaginary part: ");
	scanf("%d", &c.img);
	
	printf("\n");
	
	return c;
}

writing (struct comp c)
{
	
	printf("%d + %di", c.real, c.img);
	
	printf("\n");

}


struct comp addition(struct comp c1, struct comp c2)
{
	struct comp result;
	
	result.real = c1.real + c2.real;
	result.img = c1.img + c2.img;
	
	return result;
}

struct comp multiplication(struct comp c1, struct comp c2)
{
	struct comp result;
	
	result.real = (c1.real * c2.real) - (c1.img * c2.img);
	result.img = (c1.real * c2.img) + (c2.img * c2.real);
	
	return result;
}