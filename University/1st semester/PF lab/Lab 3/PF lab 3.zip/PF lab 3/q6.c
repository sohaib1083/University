#include<stdio.h>

int main(void)
{
	int TotDist;
	int Consump;
	int TotFuel = 0;
	
	TotDist = 10 + 10 + 5 + 15;
	Consump = 3;
	
	TotFuel = TotDist * Consump;
	
	printf("Total number of liters consumed: %d",TotFuel);
	printf("\n");
	printf("University is at a distance of: %d km",TotDist);
	
	return 0;
}
