#include<stdio.h>

int main(void)
{
int a, b, swap;

 printf("Enter two nums\n");
 scanf("%d%d", &a, &b);
 
 // swaping
 
swap = b;
b = a;
a = swap;

 // output
 
 printf("variable a stores %d\n", a);
 printf("variable b stores %d\n", b);
 
 return 0;
}
 
 
