#include<stdio.h>

main()
{

float distance, time, AvgSpeed;


    printf("input no. of kilometers (1 to 5 miles)\n");
	scanf("%f", &distance);
	
	
	printf("input time taken in hours\n");
	scanf("%f", &time);
	
	
	AvgSpeed = distance / time;
	printf("Average speed is:%f\n", AvgSpeed);
	
	return 0;
}

