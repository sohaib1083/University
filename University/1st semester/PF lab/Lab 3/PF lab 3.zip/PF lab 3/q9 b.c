#include<stdio.h>

int main(void)
{
	
    printf("*\n");
    printf("*\t*\n");
    printf("*\t*\t*\n");
    printf("*\t*\n");
    printf("*\n");
   
	return 0;
}
