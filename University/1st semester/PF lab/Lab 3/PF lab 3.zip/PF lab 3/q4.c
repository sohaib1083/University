#include<stdio.h>
#include<conio.h>
int main()
{
	
	float TaxRate, SalaryOld;
	float TaxAmount, SalaryNew;
	
	// Taking input
	printf("salary without tax \n");
    scanf("%f", &SalaryOld);
   
   printf("input tax rate(1-100)\n");
	scanf("%f", &TaxRate);
	
	
    // Doing calculation
    TaxAmount = SalaryOld * (TaxRate/100);
	SalaryNew = SalaryOld - TaxAmount;
	
	
	// Doing output
	printf("The tax amount is: %f", TaxAmount);
	printf("\n");
	printf("The salary after deduction is:%f", SalaryNew);
	
	return 0;	
}
