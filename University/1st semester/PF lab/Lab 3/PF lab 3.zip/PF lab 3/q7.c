#include<stdio.h>

int main(void)
{
	float average;
	int OriginalWeight = 110;
	
	average = (5 + 10 + 12 + 7)/4;
	
    printf("The average weight loss is : %f\n", average);
   
   OriginalWeight = OriginalWeight - (5 + 10 + 12 + 7);
   
   printf("His weight right now is : %d", OriginalWeight);
	
	return 0;
}
