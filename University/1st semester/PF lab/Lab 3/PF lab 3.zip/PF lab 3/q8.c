#include<stdio.h>

int main(void)
{
	float Principle;
	float Rate;
	float Time = 0;
	float SimpleInterest;

	
	printf("Enter principle amount (100 to 1000000)");
	scanf("%f", &Principle);
	
	printf("Enter rate of interest (5 to 10)");
	scanf("%f", &Rate);
	
	printf("Enter time period (1 to 10)");
	scanf("%f", &Time);
	
	SimpleInterest = (Principle * Rate * Time)/100;
	
	printf("\n");
	printf("The simple interest is : %f", SimpleInterest);
	
	return 0;
}
