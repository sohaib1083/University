#include <stdio.h>

int main (void){
	
	float units, cost;
	
	printf("Enter the number of units consumed: ");
	scanf("%f", &units);
	
	
while (1){
	
	if (units > 250){
		cost = (1.50*units)*1.2;
		break;
	}
	else if(units > 0 && units <= 250){
			if (units > 150 && units <= 250){
			    cost = (50*0.5) + (100*0.75) + ((units-150)*1.20);
			}
			else if (units > 50 && units <=150){
				cost = (50*0.5) + ((units-50)*0.75);
			}
			else if (units >= 0 && units <= 50){
				cost = (units*0.5);
			}
		break;
	}
}	

		printf("Your electricity cost is %.2f", cost*1.2);

	return 0;
}