#include <stdio.h>

int main (void){
	
	int i, marks = 0;
	char ans = 'c', choice = ' ';
	
    for (i=1; i<=10; i++)
	{
		do{
		   printf("Enter your choice for Q %d ", i);
	       scanf(" %c", &choice);
		} while (choice >= 'e' && choice <= 'z');

        
	if (choice == ans)
	{
		marks += 4;
	}
	else
	{
		marks--;
	}
	
	if (i==4 && marks==-4)
	{
		printf("Sorry, you did not qualify..");
		break;
    }
	
	if (marks >= 20)
    {
    	printf("Congratulations, you have quaified for the admission");
    	break;
	}
    }
}