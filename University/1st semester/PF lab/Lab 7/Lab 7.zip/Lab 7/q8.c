#include <stdio.h>

int main (void){
	
	int base_salary, sales;
	float net_salary;
	char choice = 'Y';
	
	while (choice == 'Y'){
	
	
	printf("Enter base salary: ");
	scanf("%d", &base_salary);
	
	if (base_salary >= 60000)
	{
		printf("Enter monthly sales: ");
		scanf("%d", &sales);
		
		if (sales < 10000000)
		{
		    net_salary = 0.02*sales + base_salary;
			printf("Your net salary is %f\n", net_salary); 
		}
		else
		{
			net_salary = 0.035*sales + base_salary;
			printf("Your net salary is %f\n", net_salary);
		}
	}
	else 
	{
		choice = 'N';
		printf("Exiting the program...");
	}
	
    }
}