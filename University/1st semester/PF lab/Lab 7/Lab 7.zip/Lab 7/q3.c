#include <stdio.h>

int main (void)
{
	int x, rem, count, sum =0, x1, x2, x3, x4, x5, reverse=0, i;
	
	printf("Enter 5 digits ");
	scanf("%d", &x);
	int y =x;
	
	while (x != 0)
	{
		rem = x%10;
		x = x / 10;
		sum = sum + rem;
		reverse = (reverse * 10) + rem;
	}
	
	if (sum%2 == 0)
	{
		for (i=1; i <= sum; i++)
		{
		    if (sum%i == 0)
			{
				count++;
			}
		}
		
		if (count == 2)
		{
			printf("Its a prime number.");
		}
		else
		{
			printf("Its not a prime number.");
		}
	}
	else
	{
		if (y == reverse)
		{
			printf("Its a palendrome.");
		}
		else
		{
			printf("Not a palendrome.");
		}
		
	}	
	
}