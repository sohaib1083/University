#include <stdio.h>

int main (void){
	
	int i, marks=0, pass=0, fail=0, excellent=0, AboveAvg=0;
	
	for (i=1; i<=25; i++)
	{
	
		printf("Enter the marks for student %d out of 100  ", i);
		scanf("%d", &marks);

		if (marks >= 50)
		{
			pass++;
		}
		else
		{
			fail++;
		}
		
		if (marks >= 86 && marks <= 89)
		{
			excellent++;
		}
		else if (marks >= 75 && marks <= 100)
		{
			AboveAvg++;
		}	
	}
	
	printf("%d students passed the exam\n", pass);
	printf("%d students failed the exam\n", fail);
	printf("%d students are excellent\n", excellent);
	printf("%d students got above average\n", AboveAvg);
	
}