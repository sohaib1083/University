#include <stdio.h>
#include <ctype.h>

int main (void)
{
	char Name[5], Pwd[6], NameCheck[5], PwdCheck[6];
	int i, num = 0, uppercase = 0, lowercase = 0;
	
while (1)
{	    

    printf("Enter 5 alphabets as your username \n");
	scanf("%s", &Name);

    printf("Enter a password that should be 6 characters long with at least 1 numeric, 1 capital and 1 small letter.\n");
    scanf("%s", &Pwd);
    
    //printf("%s%s", Name, Pwd);

    for (i=0; i<6; i++)
    {
        if (isdigit(Pwd[i]) == 1)
        {
        	num++;
		}
    	if (Pwd[i] >= 'A' && Pwd[i] <= 'Z')
    	{
    		uppercase++;
		}
    	if (Pwd[i] >= 'a' && Pwd[i] <= 'z')
    	{
    		lowercase++;
		}
	}
	//printf("%d%d%d", num, uppercase, lowercase);
	
	if (uppercase >= 1 && lowercase >= 1 && num >= 1)
	{
		printf("Account created successfully....\n");
		break;
	}
	else 
	{
		printf("Invalid password...\nPlease re-enter\n");
	}
	
}

// log in

while (1)
{
	printf("Enter username to log in : \n");
	scanf("%s", &NameCheck);
	
	printf("Password to log in : \n");
	scanf("%s", &PwdCheck);
	
	if (NameCheck[0] == Name[0] && NameCheck[1] == Name[1] && NameCheck[2] == Name[2] && NameCheck[3] == Name[3] && NameCheck[4] == Name[4])
	{
		if (PwdCheck[0] == Pwd[0] && PwdCheck[1] == Pwd[1] && PwdCheck[2] == Pwd[2] && PwdCheck[3] == Pwd[3] && PwdCheck[4] == Pwd[4] && PwdCheck[5] == Pwd[5]){
		printf("Welcome username, you are now logged in");
		break;
		}
	}
	else
	{
		printf("Wrong credentials....\nPlease re-enter\n");
	}
	
}
	return 0;
}