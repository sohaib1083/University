#include <stdio.h>

int  main (void)
{
	int sum = 0; 
	int num, next = 0;
	
	int num1 = 0;
	int num2 = 1;
	
	printf("Enter ending number ");
	scanf("%d", &num);
	printf("The fibonnacci series id : %d, %d,", num1, num2);
		
for (next =1; next <= num; next = num1 + num2)
{
	printf(" %d,", next);
	
	num1 = num2;
	num2 = next;
}
    sum = num2 + next-1;
    printf("\n");
	printf("The sum is %d   ", sum);
	


if (sum%2 == 0){
	printf("is divisible by 2");
}
else if (sum%3 == 0){
	printf("is divisible by 3");
}
else if (sum%5 == 0){
	printf("is divisible by 5");
}


}