#include <stdio.h>

int main (void)
{
	int num , fact=1;
	int i;
	
	printf("Enter number\n");
	scanf("%d", &num);
	
	while (num >= 0)
    {
	    for (i=1; i <= num; i++)
	    {
		fact = i * fact;
	    }
	    printf("The factorial is: %d", fact);
	    break;
	}
	
	
	return 0;
	
}