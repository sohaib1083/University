#include <stdio.h>

int main (void)
{
	int n, even=0, odd=0, fact=0;
	int num;
	int i=1;
	float sum = 0, average =0;
	
	printf("Enter the number of elements\n");
	scanf("%d", &n);
	
	if (n > 10)
	{
		do
		{
			
		printf("Enter the value of element %d (Only positive values are valid)", i);
		scanf("%d", &num);
		i++;
		
	    sum += num;
		
		if (num%2 == 0)
		{
			even++;
		}
		else
		{
			odd++;
		}
		if (num%3 == 0)
		{
			fact++;
		}
		
		}while (i < n + 1);
		
		
	printf("\n");
	printf("\n");

	
	average = sum / n;
	printf("Average = %.2f\n", average);
	printf("Odd numbers = %d\n", odd);
	printf("Even numbers = %d\n", even);
	printf("Factors of 3 = %d\n", fact);
	
	}
	else
	{
		printf("Error");
	}
	
	
}