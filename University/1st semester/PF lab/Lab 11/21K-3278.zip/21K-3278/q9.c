#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (void)
{
	int N, i;
	char *ptr;
	char name[50];
	
	// taking N
	printf("Enter number of characters:");
	scanf("%d", &N);
	
	// Dynamically allocating memory
	ptr = (char *)malloc(N * sizeof(char));
	
	// prompt for name
	printf("Enter your full name: ");
	fflush(stdin);
	gets(name);
	
	// copying to dynamic array
	strcpy(ptr, name);
	
	// Displaying dynamic array
	printf("Dynamic array = ");
	for(i=0; i<N; i++)
	{
		printf("%c", *(ptr+i));
	}      
	
}     
