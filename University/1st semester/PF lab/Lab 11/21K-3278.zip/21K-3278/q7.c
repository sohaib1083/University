#include <stdio.h>

struct student
{
	int StudentId;
	char *FirstName;
	char *LastName;
	int cellno;
	char *email;
};

struct Register
{
	char*CourseName;
	int CourseId;
};

int main (void)
{
	
	
	return 0;
}