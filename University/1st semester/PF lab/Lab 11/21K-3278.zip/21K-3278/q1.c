#include <stdio.h>

void swapped(int *num1, int *num2, int *num3)
{
	int swap1, swap2;
	
	swap1 = *num1;
	*num1 = *num2;
	swap2 = *num3;
	*num3 = swap1;
	*num2 = swap2;
	
	
}



int main (void)
{
	
	int num1, num2, num3;
	
	printf("Enter the value of num1 :");
	scanf("%d", &num1);
	
	printf("Enter the value of num2 :");
	scanf("%d", &num2);
	
	printf("Enter the value of num3 :");
	scanf("%d", &num3);
	
	printf("\n\n");
	
	printf("Before swapping: num1 is: %d, num2 is: %d, num3 is: %d\n", num1, num2, num3);
	
	swapped(&num1, &num2, &num3);
	
	printf("After swapping: num1 is: %d, num2 is: %d, num3 is: %d\n", num1, num2, num3);
	
}