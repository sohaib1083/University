#include <stdio.h>
#include <stdlib.h>

int main (void)
{
	int size, i, middle_avg;
	int *ptr;
	
	// size for array
	printf("Enter the size of array: ");
	scanf("%d", &size);
	
	// asking for blocks of memory
	ptr = (int *)malloc(size * sizeof(int));
	
	
	printf("Enter elements for this array: ");
	
	// populating array
	for (i=0; i<size; i++)
	{
		scanf("%d", ptr + i);
	}
	
	// if size is even then print both of the intersecting values.
	if (size % 2 == 0)                  
	{
	    printf("The middle elements are : %d and %d", *(ptr - 1 + (size/2)), *(ptr + (size/2)));	
	}
    else // if size is odd then print the equidistant value in between array.
	{   
	    printf("The middle element is: %d", *(ptr + (size/2)));
    }
	
	return 0;
}