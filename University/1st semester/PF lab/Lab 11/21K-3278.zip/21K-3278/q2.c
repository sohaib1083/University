#include <stdio.h>

int sum (int n, int*a)
{
	int sum = 0, i;
	
	for (i=0; i<n; i++)
	{
		
		sum = sum + a[i];
		
	}
	
	return sum;
}



int main (void)
{
	int a[100], n, i, s;
	
	printf("Enter the size of array :\n");
	scanf("%d", &n);
	
	//populating
	printf("Enter the elements of array:\n");
	
	for(i=0; i<n; i++)
	{
		scanf("%d", a+i);
	}
	
	s = sum(n, a);
	
	printf("The sum is: %d.", s);
	
	return 0;
}