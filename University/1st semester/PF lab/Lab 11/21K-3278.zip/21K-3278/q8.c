#include <stdio.h>

struct student
{
	int StudentId;
	char FirstName[50];
	char LastName[50];
	double cellno;
	char email[50];
	
	struct Register
    {
	char CourseName[50];
	int CourseId;
    }reg;
	
};

int main (void)
{
	struct student std[5];
	int i;
	
	printf("**********Taking student data************\n\n");

	// for populating
	for (i=0; i<5; i++)
	{
		printf("Enter student %d id:", i+1);
		scanf("%d", &std[i].StudentId);
		
		printf("Enter student %d first name:", i+1);
		fflush(stdin);
		gets(std[i].FirstName);
		
		printf("Enter student %d last name:", i+1);
		fflush(stdin);
		gets(std[i].LastName);

		printf("Enter student %d cell number:", i+1);
		scanf("%lf", &std[i].cellno);
		
		printf("Enter student %d email:", i+1);
		fflush(stdin);
		gets(std[i].email);
		
		printf("Enter student %d course id:", i+1);
		scanf("%d", &std[i].reg.CourseId);
		
		printf("Enter student %d course name:", i+1);
		fflush(stdin);
		gets(std[i].reg.CourseName);
		
		printf("\n");
				
	}
	
	printf("\n\n");
	
	printf("**********printing student data************\n\n");
	
	// for printing
	for (i=0; i<5; i++)
	{
		printf("student %d id: %d\n", i+1, std[i].StudentId);
		
		printf("student %d first name: ", i+1);
		
		puts(std[i].FirstName);
		
		printf("student %d last name: ", i+1);
		puts(std[i].LastName);
		
		printf("student %d cell number: (+92)%.0lf\n", i+1, std[i].cellno);
		
		printf("student %d email: ", i+1);
		puts(std[i].email);
		
		printf("student %d course id: %d\n", i+1, std[i].reg.CourseId);
		
		printf("student %d course name: ", i+1);
		puts(std[i].reg.CourseName);	
		
		printf("\n\n");	
	}	

	return 0;
}