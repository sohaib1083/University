#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (void)
{
	int N, i, N1;
	char *ptr;
	char *ptr1;
	char name[50];
	char roll_num[50];
	
	// taking N
	printf("Enter number of characters:");
	scanf("%d", &N);
	
	// Dynamically allocating memory
	ptr = (char *)malloc(N * sizeof(char));
	
	// prompt for name
	printf("Enter your full name: ");
	fflush(stdin);
	gets(name);
	
	// copying to dynamic array
	strcpy(ptr, name);
	
	printf("\n\n");
	
	printf("**********before***********\n");
	
	// Displaying dynamic array
	printf("Dynamic array = ");
	for(i=0; i<N; i++)
	{
		printf("%c", *(ptr+i));
	}      
	printf("\n\n");
	
    
	// taking new N
	printf("Enter number of characters:");
	scanf("%d", &N1);
	
	// Dynamically allocating memory
	ptr1 = (char *)calloc(N1, sizeof(char));
	
	// prompt for name
	printf("Enter your student id: ");
	fflush(stdin);
	gets(roll_num);
	

	// copying to dynamic array
	strcpy(ptr1, roll_num);
	
	strcat(ptr1, ptr);
	
	printf("\n\n");
	
	printf("**********after***********\n");
	
	// Displaying dynamic array
	printf("Dynamic array = ");
	for(i=0; i<N + N1; i++)
	{
		printf("%c", *(ptr1+i));
	}      
	
	
	return 0;
}   