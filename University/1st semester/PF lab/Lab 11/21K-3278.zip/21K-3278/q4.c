#include<stdio.h>

int *wordCount(char *s)
{
    int i  , w = 0;
    int *ptr;
    
	for(i = 0 ; s[i] ; i++)  
    {
    	if(s[i] == 32)
    	{
    		w++;
		}
	}
	if(i > 0)
	{
		w++;
	}
	ptr = &w;
	return ptr; 	
}
int main(void)
{
 
    char s[2000];  
    int count;
    int *count_ptr;
    
    // Taking input
    printf("Enter a String: ");
    fflush(stdin);
    gets(s);
    
    // repliacting
    printf("You have entered : %s\n" , s) ;
    
    // function calling
    count_ptr = wordCount(s);
    
    // giving output
    printf("THERE ARE %d WORDS" , *count_ptr);
}