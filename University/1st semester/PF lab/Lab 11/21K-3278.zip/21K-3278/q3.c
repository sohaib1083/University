#include <stdio.h>

int maximum (int *a)
{
	// initialising max as the first integer
	int max = *a, i;
	
	for (i=0; i<10; i++)
	{
		if (*(a+i) > max){
			max = *(a+i);
		}
	}
	
	return max;
	
}

int minimum (int *a)
{
    // initialising min as the first integer
	int min = *a, i;
	
	for (i=0; i<10; i++)
	{
		if (*(a+i) < min){
			min = *(a+i);
		}
	}
	
	return min;
	
}

int sum (int *a)
{
	
	int s = 0, i;
	
	for (i=0; i<10; i++)
	{
		// adding all integers to variable 's'.
		s = s + *(a+i);

	}
	
	return s;
	
}


void display (int *a)
{
	int max, min, s;
	
	// calling respective functions.
	max = maximum(a);
	min = minimum(a);
	s = sum(a);
	
	// printing the output of functions on the screen.
	printf("The maximum number is %d.\n", max);
	printf("The minimum number is %d.\n", min);
	printf("The sum of all digits is %d.\n", s);
	
	
	
}


int main (void){
	
	int a[10], i;
	
	// populating array of 10 integers
	for(i=0; i<10; i++){
		printf("Enter number %d : ", i+1);
		scanf("%d", (a+i));
	}
	
	// calling function
	display(a);
	
	
}