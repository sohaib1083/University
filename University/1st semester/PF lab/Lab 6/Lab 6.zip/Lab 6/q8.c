#include <stdio.h>

int main (void){
	
	char choice1, First = ' ', Second = ' ', Third = ' ';
	float Usb = 0, Handfree = 0, Charger = 0;
	
	printf("============Items available are:============\n");
	printf("1. USB\n2. Handsfree\n3. Charger\nEnter the number of items do you want to purchase:");
	scanf(" %c", &choice1);
	
	printf("\nItems available:\nEnter 1 for USB\nEnter 2 for Handsfree\nEnter 3 for Charger\n");
	printf("----------------------------------------------------------\n");
    
    switch (choice1)
    {
    	case '1':
		{
		printf("Enter item\n");
		scanf(" %c", &First);
	    break;
	    
	    } 
		case '2':
		{
			printf("Enter first item\n");
			scanf(" %c", &First);
			printf("Enter second item\n");
			scanf(" %c", &Second);
			break;
		} 
		case '3':
		{
			printf("Enter first item\n");
			scanf(" %c", &First);
			printf("Enter second item\n");
			scanf(" %c", &Second);
			printf("Enter third item\n");
			scanf(" %c", &Third);
			break;
		} 
		default:
		    printf("Error\n");	
    }
    
    
  
    switch (First)
    {
    	case ' ':{
			break;
		}
    	case '1':{
			printf("Enter how many USB do you want to purchase\n");
			scanf("%f", &Usb);
			break;
		}	
    	case '2':{
			printf("Enter how many Handfree do you want to purchase\n");
			scanf("%f", &Handfree);
			break;
		}	
    	case '3':{
			printf("Enter how many Charger do you want to purchase\n");
			scanf("%f", &Charger);
			break;
		}	
    	default:
    		printf("Error\n");
    }
    
    
    
        
	switch (Second)
    {
    	case ' ':{
			break;
		}
    	case '1':{
			printf("Enter how many USB do you want to purchase\n");
			scanf("%f", &Usb);
			break;
		}	
    	case '2':{
			printf("Enter how many Handfree do you want to purchase\n");
			scanf("%f", &Handfree);
			break;
		}	
    	case '3':{
			printf("Enter how many Charger do you want to purchase\n");
			scanf("%f", &Charger);
			break;
		}	
    	default:
    		printf("Error\n");
    }
    
    
    switch (Third)
    {
    	case ' ':{
			break;
		}
    	case '1':{
			printf("Enter how many USB do you want to purchase\n");
			scanf("%f", &Usb);
			break;
		}	
    	case '2':{
			printf("Enter how many Handfree do you want to purchase\n");
			scanf("%f", &Handfree);
			break;
		}	
    	case '3':{
			printf("Enter how many Charger do you want to purchase\n");
			scanf("%f", &Charger);
			break;
		}	
    	default:
    		printf("Error\n");
    }
    

    float Total = (Usb * 800) + (Handfree * 1000) + (Charger * 2000);
    
    if (Usb != 0){
    	printf("You have purchased %.0f usb(s) having value %.0f\n", Usb, Usb * 800);
	}
    if (Handfree != 0){
    	printf("You have purchased %.0f Handfree (s) having value %.0f\n", Handfree, Handfree * 1000);
	}
    if (Charger != 0){
    	printf("You have purchased %.0f Charger (s) having value %0.f\n", Charger, Charger * 2000);
	}
    
    printf("The total amount is %.0f \n", Total);
    
    
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    