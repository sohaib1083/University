#include <stdio.h>


int main (void)
{
	char char1, char2;
	
	
	printf("(f)File\n(d)Edit\n(s)Search\n(e)Execute\n");
	scanf(" %c", &char1);
	
	
	switch(char1)
	{
		case 'f':
			{
			   	printf("(n)New\n(o)Open\n(s)Save as\n(c)Close");
			   	scanf(" %c", &char2);
			   	
			   	switch(char2)
			   	{
			   		case 'n':
			   		{
			   			printf("Making a new file\n");
			   			break;
					}	
			   		case 'o':
			   		{
			   			printf("Opening new file\n");
			   			break;
				    }	
			   		case 's':
			   		{
			   		    printf("Saving file\n");
			   		    break;	
					}
			   		case 'c':
			   		{
			   			printf("Closing this file\n");
			   		    break;
					}
					default:
					printf("Invalid choice\n");
				}
			   	break;	   	
			}
		
		case 'd':
			{
				printf("(u)Undo\n(s)Select All\n");
			   	scanf(" %c", &char2);
			   	
			   	switch(char2)
			   	{
			   		case 'u':
			   		{
			   			printf("Undoing \n");
			   			break;
					}	
			   		case 's':
			   		{
			   			printf("Selecting all\n");
			   			break;
				    }
			   	    default:
					printf("Invalid choice\n");
			    }
				break;
			}
		
		case 's':
			{
				printf("(f)Find\n(r)Replace\n");
			   	scanf(" %c", &char2);
			   	
			   	switch(char2)
			   	{
			   		case 'f':
			   		{
			   			printf("Finding in file \n");
			   			break;
					}	
			   		case 'r':
			   		{
			   			printf("replacing in file\n");
			   			break;
				    }
			   	    default:
					printf("Invalid choice\n");
			    }
				break;
			}
			
		case 'e':
			{
				printf("(c)Compile\n(r)Run\n(z)Compile and Run\n(b)Rebuild\n(s)Syntax Check");
			   	scanf(" %c", &char2);
			   		switch(char2)
			   	{
			   		case 'c':
			   		{
			   			printf("Compiling... \n");
			   			break;
					}	
			   		case 'r':
			   		{
			   			printf("Running...\n");
			   			break;
				    }
				    	case 'z':
			   		{
			   			printf("Compiling and running... \n");
			   			break;
					}	
			   		case 'b':
			   		{
			   			printf("Rebuilding...\n");
			   			break;
				    }
				    case 's':
			   		{
			   			printf("Checking syntax...\n");
			   			break;
				    }
			   	    default:
					printf("Invalid choice\n");
			    }
				break;
			}
		default:
			    printf("Invalid choice");
			
	}
		
	return 0;
}
