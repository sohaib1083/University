#include <stdio.h>

int main (void){
	
	char choice1;
	
	printf("Enter the weekday\nMonday(1)\nTuesday(2)\nWednesday(3)\nThursday(4)\nFriday(5)\nSaturday(6)\nSunday(7)\n");
	scanf(" %c", &choice1);
	
	switch(choice1)
	{
		case '1':
		{	
			printf("I will go to school\n");
		    break;
	    }
		case '2':
		{	
	        printf("I will go to school\n");
	        break;    
	    }
		case '3':
		{	
			printf("I will go to school\n");
		    break;	    
	    }
		case '4':
		{	
			printf("I will go to school\n");
		    break;	
	    }
		case '5':
		{
			printf("I will go to school\n");
		    break;
	    }
		case '6':
		{	
			printf("I will go to play cricket\n");
		    break;
	    }
		case '7':
		{
			
		    break;
	    }
		    
		    printf("Error\n");
		    
	}	
}