#include <stdio.h>

int main (void){
	
    char Choice1, Choice2;
	
	printf("Enter the type of coffee\nBlack(B)\nWhite(W)");
	scanf("%c", &Choice1);
	
	switch (Choice1)
	{
		case 'B':
		printf("Enter size\nSingle(s)\nDouble(d)");
		scanf(" %c", &Choice2);
		
		switch (Choice2)
		{
			case 's':
			printf("Put water: 20 mins\nSugar: 20 mins\nMix well: 25 mins\nAdd coffee: 15 mins\n Add Milk: 0 mins\nMix well: 25 mins");
			break;
			
			case 'd':
			printf("Put water: 40 mins\nSugar: 40 mins\nMix well: 50 mins\nAdd coffee: 30 mins\n Add Milk: 0 mins\nMix well:  mins");
			break;		
		}	
		break;
		
		case 'W':
		printf("Enter size\nSingle(s)\nDouble(d)");
		scanf(" %c", &Choice2);
		
		switch (Choice2)
		{
			case 's':
			printf("Put water: 15 mins\nSugar: 15 mins\nMix well: 20 mins\nAdd coffee: 2 mins\nAdd Milk: 4 mins\nMix well: 20 mins");
			break;
			
			case 'd':
			printf("Put water: 30 mins\nSugar: 30 mins\nMix well: 40 mins\nAdd coffee: 4 mins\n Add Milk: 8 mins\nMix well: 40 mins");
			break;		
		}	
		break;	
	}
	
	return 0;
	
}

