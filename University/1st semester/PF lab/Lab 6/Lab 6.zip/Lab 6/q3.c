#include <stdio.h>

int main (void){
	
float Nts, Fsc, MaxNts, MaxFsc, Nperc, Fperc;

printf("Enter marks obtained in fsc:\nEnter maximum marks for fsc:\n");
scanf("%f%f", &Fsc, &MaxFsc);

printf("Enter marks obtained in nts:\nEnter maximum marks for nts:\n");
scanf("%f%f", &Nts, &MaxNts);

Nperc = (Nts/MaxNts) * 100; 
Fperc = (Fsc/MaxFsc) * 100;

if (Fperc > 70){
	if (Nperc >= 70 && Nperc >= 70){
		printf("You are selected in NUST University Mechanical Department\n");
	}
	else if (Nperc >= 60 && Nperc < 70){
		printf("You are selected in NUST University Electrical Department\n");
	}  
    else if (Nperc >= 50 && Nperc < 60){
		printf("You are selected in NUST University Telecommunication Department\n");
	}	
}
else if (Fperc < 70 && Nperc > 50){
	if (Fperc >= 60){
	    printf("You are selected in NED University IT Department\n");
    }
	else if (Fperc >= 50 && Fperc < 60){
	    printf("You are selected in NED University Chemical Department\n");	
    }
    else if (Fperc >= 40 && Fperc < 50){
	    printf("You are selected in NED University Computer Department\n");
    }
}
return 0;
}