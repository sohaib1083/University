#include <stdio.h>

int main (void){
	
	int choice, num, sum = 0;
	char exit = 'Y';
	
	do
	{
		
		printf("1. Economy\n2. AC Standard\n3. Business Class\n");
		printf("Enter your choice: ");
		scanf("%d", &choice);
		
		switch (choice)
		{
			
			case 1:
				{
					printf("Enter the number of seats you want: ");
					scanf("%d", &num);
					num = num * 600;
					sum += num; 
					break;
				}
			
			case 2:
				{
					printf("Enter the number of seats you want: ");
					scanf("%d", &num);
					num = num * 1000;
					sum += num; 
					break;
				}
				
			case 3:
				{
					printf("Enter the number of seats you want: ");
					scanf("%d", &num);
					num = num * 2000;
					sum += num; 
					break;
				}
			default:
				printf("Error");
		}
		
		printf("Do you want to make bookings? (Y/N)");
		scanf(" %c", &exit);
		
	}while (exit != 'N');

printf("Your fare is: %d ", sum);

return 0;
}