#include <stdio.h>

int main (void){
	
float s1, s2, s3, ans;

printf("Enter all three sides of the triangle: \n");
scanf("%f%f%f", &s1, &s2, &s3);

(s1 == s2 && s2 == s3 ? printf("Equilateral"):(s1 == s2 || s2 == s3 || s1 == s3 ? printf("issoceles"):printf("scalene")));

return 0;		
}

