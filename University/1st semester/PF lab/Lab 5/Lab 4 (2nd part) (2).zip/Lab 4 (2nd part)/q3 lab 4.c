#include<stdio.h>

int main(void)
{
	
float a=2, b=4, c=2;
float x, y, z; 

free(z);

x = a + b / c + (int)b % 2 * a - c;
y = a++ * (a / b * c) + b--;
z = a++ * (a / b * c) + --b;

printf("Answer for a is : %.1f\n", x);
printf("Answer for b is : %.1f\n", y);
printf("Answer for c is : %.1f\n", z);

}

