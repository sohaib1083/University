#include<stdio.h>

int main(void)
{
	
	int True = 1;
	int False = 0;
	int x, y;
	
	// NOT has higher precedence therefore it is served first, then AND is served 
	// (FALSE AND FALSE) gives FALSE on the left then the OR gate finally gives True 
	// combined with the false gate since OR only needs or more True to get True. 
	
	x = True || False && !True;
	
	printf("the first answer is : %d \n", x);
	
	
	//The char is compared, since A doesnt come after Z so it returns a value of 0 which is stored 
	// in variable y.
	
	y = ('A' > 'Z');
	printf("the second answer is : %d \n", y);
	
	
	
	
	
	

}

