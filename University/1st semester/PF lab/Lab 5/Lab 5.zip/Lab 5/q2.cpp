#include<stdio.h>

int main(void)
{
	int year;
	
	printf("Enter your YEAR OF BIRTH");
	scanf("%d", &year);
	
	int Age = 2021 - year;
	
	if (Age >= 18)
	{
		printf("You're eligible to vote\n");
	}
	else
	{
		printf("You're under age\n");
	}
	
return 0;	
}
