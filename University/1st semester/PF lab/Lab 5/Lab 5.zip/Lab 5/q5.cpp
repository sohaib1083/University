#include<stdio.h>

int main(void)
{
	char choice;
	
	printf("Are you sure to save (+ or - or * or / \n)");
	scanf("%c", &choice);
	
	
	int num1, num2;
	printf("enter numbers \n");
	scanf("%d%d", &num1, &num2);
	

	
	if (choice == '+')
	{
		printf("Answer : %d ", num1 + num2);
	}
	if (choice == '-')
	{
		printf("Answer %d : ", num1 - num2);
	}
	if (choice == '*')
	{
		printf("Answer : %d ", num1 * num2);
	}
	if (choice == '/')
	{
		printf("Answer : %.1f ", (float)num1 / (float)num2);
	}
return 0;	
}
