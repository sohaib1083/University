#include<stdio.h>

int main(void)
{
	int X;
	
	printf("enter month\n");
	scanf("%d", &X);
	
	if (X == 1 || X == 3 || X == 5 || X == 7 || X == 8 || X == 10 || X == 12)
	{
		printf("This month has 31 days \n", X);
	}
	else if (X == 4 || X == 6 || X == 9 || X == 11)
	{
		printf("This month has 30 days", X);
	}
	else if(X == 2)
	{
		printf("This month has 28 or 29 days", X);
	}
}