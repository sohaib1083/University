#include<stdio.h>

int main(void)
{
	int Temp;
	
	printf("Enter temperature");
	scanf("%d", &Temp);
	
	if (Temp <= 0 )
	{
		printf("It is freezing point\n");
	}
	if (Temp > 0 && Temp <= 10)
	{
		printf("It is very Cold weather. \n");
	}
	if (Temp > 10 && Temp <= 20)
	{
		printf("It is Cold weather\n");
	}
	if (Temp > 20 && Temp <= 30)
	{
		printf("Normal temp\n");
	}
		if (Temp > 30 && Temp <= 40)
	{
		printf("Hot weather\n");
	}
return 0;	
}

