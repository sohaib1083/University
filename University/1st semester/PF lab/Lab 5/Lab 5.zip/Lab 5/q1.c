#include<stdio.h>

int main(void)
{
	int num;
	
	printf("Enter the Number to check");
	scanf("%d", &num);
	
	if (num%2 == 0)
	{
		printf("Its a multiple of 2\n");
	}
	if (num%3 == 0)
	{
		printf("Its a multiple of 3\n");
	}
	if (num%5 == 0)
	{
		printf("Its a multiple of 5\n");
	}
	
return 0;	
}
