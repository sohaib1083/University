#include<stdio.h>

int main(void)
{
	char X;
	
	printf("enter alphabet");
	scanf("%c", &X);
	
	if (X >= 'A' && X <= 'Z')
	{
		printf("UPPER CASE");
	}
	
	if (X >= 'a' && X <= 'z')
	{
		printf("LOWER CASE");
	}
		if (X >= '0' && X <= '9')
	{
		printf("DIGIT");
	}
	else 
	{
		printf("SPECIAL CHAR");
	}
	
	return 0;

}
