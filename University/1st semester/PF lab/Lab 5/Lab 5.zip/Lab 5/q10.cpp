#include<stdio.h>
#include<math.h>

int main(void)
{
	float a, b, c;
	
	printf("enter a, b and c\n");
	scanf("%f%f%f", &a, &b, &c);
	
	float Discr;
//	Discr = (b * b) − (4 * a * c);
	
	Discr = (b * b);
	Discr = Discr- (4 * a * c);
	
	if (Discr > 0)
	{
	float root1x = (-b + sqrt(Discr)) / (2*a);
    float root2x = (-b - sqrt(Discr)) / (2*a);

	printf("Root 1 is %.1f\n", root1x);
	printf("Root 2 is %.1f\n", root2x);
	}
	else if (Discr == 0)
	{
	float root1y	= -b / (2*a);
	printf("Root 1 is equal to root 2 : %.1f\n", root1y);
	}
	if (Discr < 0)
	{
	float root1z = -b / (2*a);
	float root2z =  b / (2*a);

	printf("Root 1 is %.1f\n", root1z);
	printf("Root 2 is %.1f\n", root2z);
	}
}