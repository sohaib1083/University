#include<stdio.h>

int main(void)
{
	char X;
	
	printf("enter alphabet\n");
	scanf("%c", &X);
	
	if (X == 'a' || X == 'e' || X == 'i' || X == 'o' || X == 'u')
	{
		printf(" %c is a Vowel", X);
	}
	else 
	{
		printf(" %c is a consonant", X);
	}
	
}