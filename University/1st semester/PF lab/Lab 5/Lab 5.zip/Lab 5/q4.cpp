#include<stdio.h>

int main(void)
{
	char choice;
	
	printf("Are you sure to save (S/s or N/n)");
	scanf("%c", &choice);
	

	
	if (choice == 'S' || choice == 's')
	{
		printf("saved");
	}
	if (choice == 'N' || choice == 'n')
	{
		printf("Not saved");
	}
	
return 0;	
}
